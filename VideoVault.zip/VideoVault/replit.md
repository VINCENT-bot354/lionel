# Video Sharing Platform

## Overview

This is a full-stack video sharing platform built with React, Express, and PostgreSQL. The application allows users to upload, view, and manage videos with features like video recording, thumbnail generation, and a responsive web interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **Routing**: Wouter for client-side navigation
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **API Design**: RESTful API with proper HTTP status codes
- **File Handling**: Multer for video and image uploads
- **Logging**: Custom middleware for request/response logging

### Database Architecture
- **Database**: PostgreSQL 16 (configured for standard PostgreSQL)
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema updates
- **Connection**: Connection pooling with node-postgres (pg)
- **Production**: SSL enabled with proper connection handling

## Key Components

### Database Schema
- **Users Table**: Basic user management with username/password
- **Videos Table**: Video metadata including title, description, filename, thumbnail, duration, views, and timestamps
- **Validation**: Zod schemas for type-safe data validation

### File Storage
- **Video Storage**: Local filesystem storage in `uploads/videos/`
- **Thumbnail Storage**: Local filesystem storage in `uploads/thumbnails/`
- **File Limits**: 100MB for videos, 10MB for thumbnails
- **Supported Formats**: MP4, WebM, AVI, MOV for videos; JPEG, PNG, GIF, WebP for thumbnails

### API Endpoints
- `GET /api/videos` - List all videos
- `GET /api/videos/:id` - Get specific video details
- `POST /api/videos` - Upload new video with thumbnail
- `POST /api/videos/:id/view` - Increment view count
- `PUT /api/videos/:id` - Update video metadata
- `DELETE /api/videos/:id` - Delete video

### Frontend Pages
- **Home Page**: Video grid with thumbnails and metadata
- **Video Page**: Individual video player with related videos
- **Admin Page**: Video upload and management interface
- **404 Page**: Error handling for invalid routes

### UI Components
- **VideoCard**: Reusable video thumbnail component
- **VideoRecorder**: WebRTC-based video recording component
- **UI Library**: Complete shadcn/ui component library for consistent design

## Data Flow

1. **Video Upload Flow**:
   - User uploads video file and optional thumbnail via admin interface
   - Multer processes files and stores them in local directories
   - Video metadata is validated with Zod schemas
   - Data is inserted into PostgreSQL via Drizzle ORM
   - Success response triggers UI update via TanStack Query

2. **Video Viewing Flow**:
   - User navigates to video page
   - Frontend fetches video metadata from API
   - Video file is served directly from uploads directory
   - View count is incremented via separate API call
   - Related videos are fetched and displayed

3. **Video Recording Flow**:
   - User activates camera via WebRTC getUserMedia API
   - MediaRecorder captures video stream
   - Recorded blob is processed and can be uploaded like regular files
   - Thumbnail can be generated from video frame

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for Neon database
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **multer**: File upload handling
- **zod**: Schema validation
- **date-fns**: Date formatting utilities

### Development Dependencies
- **vite**: Frontend build tool with HMR
- **typescript**: Type checking
- **tailwindcss**: Utility-first CSS framework
- **eslint**: Code linting
- **@replit/vite-plugin-***: Replit-specific development tools

## Deployment Strategy

### Development
- Frontend and backend run concurrently in development mode
- Vite dev server handles frontend with HMR
- Express server runs with tsx for TypeScript execution
- File uploads stored in local uploads directory

### Production Build
- Frontend builds to static files in `dist/public`
- Backend compiles to single bundle in `dist/index.js`
- Express serves both API and static files
- Database migrations applied via `drizzle-kit push`

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string (required)
- `NODE_ENV`: Environment mode (development/production)
- `PORT`: Server port (defaults to 5000)
- File storage paths are relative to project root

### Deployment Strategy

#### Render.com Deployment
- **Database**: PostgreSQL 16 on Render
- **Build Command**: `npm install && npm run build`
- **Start Command**: `npm start`
- **Environment**: Production-ready with SSL and connection pooling
- **File Storage**: Persistent disk for uploads directory
- **Health Check**: Available at root endpoint (/)

#### Alternative Deployment Options
- **Docker**: Dockerfile and .dockerignore provided
- **Manual Server**: Standard Node.js deployment
- **Environment Variables**: .env.example template provided

### Scalability Considerations
- Database uses connection pooling for better performance
- Video files served with range request support for streaming
- SSL connections enabled for production environments
- File uploads are stored locally (consider cloud storage for scaling)
- API responses are optimized with proper caching headers
- Health check endpoint for monitoring and load balancing