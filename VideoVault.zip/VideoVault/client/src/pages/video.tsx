import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { ArrowLeft, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import VideoCard from "@/components/video-card";
import type { Video } from "@shared/schema";
import { useEffect, useRef } from "react";

export default function VideoPage() {
  const { id } = useParams<{ id: string }>();
  const videoId = parseInt(id || '0');
  const hasIncrementedViews = useRef(false);

  const { data: video, isLoading } = useQuery<Video>({
    queryKey: ['/api/videos', videoId],
    enabled: !!videoId,
  });

  const { data: allVideos } = useQuery<Video[]>({
    queryKey: ['/api/videos'],
  });

  // Simple view increment on mount - only once per video
  useEffect(() => {
    if (videoId && !hasIncrementedViews.current) {
      hasIncrementedViews.current = true;
      // Simple fetch without causing re-renders
      fetch(`/api/videos/${videoId}/view`, { method: 'POST' })
        .catch(console.error);
    }
  }, [videoId]);

  const relatedVideos = allVideos?.filter(v => v.id !== videoId).slice(0, 3) || [];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Skeleton className="h-8 w-32 mb-6" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Skeleton className="w-full h-64 md:h-96 rounded-xl mb-6" />
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <Skeleton className="h-8 w-3/4 mb-4" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3" />
              </div>
            </div>
            <div className="lg:col-span-1">
              <Skeleton className="h-6 w-32 mb-4" />
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!video) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Video Not Found</h2>
          <p className="text-gray-600 mb-4">The video you're looking for doesn't exist.</p>
          <Link href="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center mr-3">
                <div className="w-3 h-3 bg-white rounded-full"></div>
              </div>
              <h1 className="text-xl font-bold text-gray-900">VideoHub</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-4">
          <Link href="/">
            <Button variant="ghost" className="flex items-center text-blue-600 hover:text-blue-700">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Videos
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* Video Player */}
            <div className="bg-black rounded-xl overflow-hidden shadow-lg">
              <video 
                className="w-full h-64 md:h-96" 
                controls 
                poster={video.thumbnailPath ? `/uploads/thumbnails/${video.thumbnailPath}` : undefined}
              >
                <source src={`/uploads/videos/${video.filename}`} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            </div>

            {/* Video Information */}
            <div className="mt-6 bg-white rounded-xl p-6 shadow-sm">
              <h1 className="text-2xl font-bold text-gray-900 mb-3">{video.title}</h1>
              <div className="flex items-center text-gray-600 text-sm mb-4 space-x-4">
                <span>{video.views || 0} views</span>
                <span>{formatDistanceToNow(new Date(video.createdAt || Date.now()), { addSuffix: true })}</span>
                {video.duration && <span>Duration: {Math.floor(video.duration / 60)}:{(video.duration % 60).toString().padStart(2, '0')}</span>}
              </div>
              {video.description && (
                <div className="border-t pt-4">
                  <h3 className="font-semibold text-gray-900 mb-2">Description</h3>
                  <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{video.description}</p>
                </div>
              )}
            </div>
          </div>

          {/* Related Videos Sidebar */}
          <div className="lg:col-span-1">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Related Videos</h3>
            <div className="space-y-4">
              {relatedVideos.length > 0 ? (
                relatedVideos.map((relatedVideo) => (
                  <Link key={relatedVideo.id} href={`/video/${relatedVideo.id}`}>
                    <Card className="hover:shadow-md transition-shadow cursor-pointer">
                      <CardContent className="p-3">
                        <div className="flex space-x-3">
                          <div className="relative">
                            {relatedVideo.thumbnailPath ? (
                              <img 
                                src={`/uploads/thumbnails/${relatedVideo.thumbnailPath}`}
                                alt={relatedVideo.title}
                                className="w-20 h-14 object-cover rounded"
                              />
                            ) : (
                              <div className="w-20 h-14 bg-gray-200 rounded flex items-center justify-center">
                                <Play className="h-6 w-6 text-gray-400" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900 text-sm line-clamp-2">{relatedVideo.title}</h4>
                            <p className="text-gray-600 text-xs mt-1">{relatedVideo.views || 0} views</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))
              ) : (
                <p className="text-gray-500 text-sm">No related videos available.</p>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}