import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowLeft, Video, Save, Upload, Camera, Trash2, Edit } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import VideoRecorder from "@/components/video-recorder";
import type { Video as VideoType } from "@shared/schema";

export default function Admin() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);
  const [recordedVideo, setRecordedVideo] = useState<Blob | null>(null);
  const [showRecorder, setShowRecorder] = useState(false);

  const { toast } = useToast();

  const { data: videos, isLoading } = useQuery<VideoType[]>({
    queryKey: ['/api/videos'],
  });

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!title.trim()) {
        throw new Error("Video title is required");
      }

      const formData = new FormData();
      formData.append('title', title);
      if (description) formData.append('description', description);
      
      if (recordedVideo) {
        formData.append('video', recordedVideo, 'recorded-video.webm');
      } else if (videoFile) {
        formData.append('video', videoFile);
      } else {
        throw new Error("Please record or upload a video");
      }

      if (thumbnailFile) {
        formData.append('thumbnail', thumbnailFile);
      }

      const response = await fetch('/api/videos', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Upload failed');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({
        title: "Success",
        description: "Video uploaded successfully!",
      });
      // Reset form
      setTitle("");
      setDescription("");
      setVideoFile(null);
      setThumbnailFile(null);
      setThumbnailPreview(null);
      setRecordedVideo(null);
      setShowRecorder(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/videos/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
      toast({
        title: "Success",
        description: "Video deleted successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleThumbnailUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setThumbnailFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setThumbnailPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoFile(file);
      setRecordedVideo(null); // Clear recorded video if file is uploaded
    }
  };

  const handleVideoRecorded = (blob: Blob, thumbnailBlob?: Blob) => {
    setRecordedVideo(blob);
    setVideoFile(null); // Clear uploaded file if video is recorded
    
    if (thumbnailBlob) {
      const thumbnailFile = new File([thumbnailBlob], 'thumbnail.png', { type: 'image/png' });
      setThumbnailFile(thumbnailFile);
      setThumbnailPreview(URL.createObjectURL(thumbnailBlob));
    }
  };

  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this video?")) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center mr-3">
                <div className="w-3 h-3 bg-white rounded-full"></div>
              </div>
              <h1 className="text-xl font-bold text-gray-900">VideoHub</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" className="flex items-center text-blue-600 hover:text-blue-700">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Videos
            </Button>
          </Link>
        </div>

        <div className="space-y-8">
          {/* Upload Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Video className="h-5 w-5 mr-2" />
                Admin Panel - Video Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Video Recording/Upload Section */}
                <div className="space-y-6">
                  <div>
                    <Label htmlFor="title">Video Title *</Label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Enter video title..."
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Enter video description..."
                      className="mt-1"
                      rows={3}
                    />
                  </div>

                  {/* Recording Section */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>Record Video</Label>
                      <Button
                        variant={showRecorder ? "destructive" : "default"}
                        size="sm"
                        onClick={() => setShowRecorder(!showRecorder)}
                      >
                        <Camera className="h-4 w-4 mr-2" />
                        {showRecorder ? "Cancel Recording" : "Start Recording"}
                      </Button>
                    </div>

                    {showRecorder && (
                      <VideoRecorder
                        onVideoRecorded={handleVideoRecorded}
                        onClose={() => setShowRecorder(false)}
                      />
                    )}
                  </div>

                  {/* File Upload */}
                  <div>
                    <Label htmlFor="videoFile">Or Upload Video File</Label>
                    <div className="mt-2 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                      <div className="space-y-1 text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="flex text-sm text-gray-600">
                          <label
                            htmlFor="videoFile"
                            className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
                          >
                            <span>Upload a video</span>
                            <input
                              id="videoFile"
                              type="file"
                              accept="video/*"
                              onChange={handleVideoUpload}
                              className="sr-only"
                            />
                          </label>
                          <p className="pl-1">or drag and drop</p>
                        </div>
                        <p className="text-xs text-gray-500">MP4, WebM, AVI up to 100MB</p>
                      </div>
                    </div>
                    {videoFile && (
                      <p className="mt-2 text-sm text-gray-600">Selected: {videoFile.name}</p>
                    )}
                    {recordedVideo && (
                      <p className="mt-2 text-sm text-green-600">Recorded video ready for upload</p>
                    )}
                  </div>
                </div>

                {/* Thumbnail Section */}
                <div className="space-y-6">
                  <div>
                    <Label>Thumbnail Preview</Label>
                    <div className="mt-2 border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                      {thumbnailPreview ? (
                        <img
                          src={thumbnailPreview}
                          alt="Thumbnail preview"
                          className="max-w-full h-32 object-cover rounded-lg mx-auto"
                        />
                      ) : (
                        <div className="text-gray-500">
                          <Camera className="h-8 w-8 mx-auto mb-2" />
                          <p>No thumbnail selected</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="thumbnailFile">Upload Thumbnail</Label>
                    <div className="mt-2">
                      <label
                        htmlFor="thumbnailFile"
                        className="w-full flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer hover:bg-gray-50"
                      >
                        <div className="space-y-1 text-center">
                          <Upload className="mx-auto h-8 w-8 text-gray-400" />
                          <div className="text-sm text-gray-600">
                            <span className="font-medium text-blue-600">Upload thumbnail</span>
                          </div>
                          <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                        </div>
                      </label>
                      <input
                        id="thumbnailFile"
                        type="file"
                        accept="image/*"
                        onChange={handleThumbnailUpload}
                        className="sr-only"
                      />
                    </div>
                  </div>

                  <Button
                    onClick={() => uploadMutation.mutate()}
                    disabled={uploadMutation.isPending || (!recordedVideo && !videoFile) || !title.trim()}
                    className="w-full"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {uploadMutation.isPending ? "Uploading..." : "Save Video"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Video Management */}
          <Card>
            <CardHeader>
              <CardTitle>Manage Videos</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="flex items-center space-x-4">
                      <Skeleton className="h-12 w-12" />
                      <div className="flex-1">
                        <Skeleton className="h-4 w-full mb-2" />
                        <Skeleton className="h-3 w-1/2" />
                      </div>
                      <Skeleton className="h-8 w-16" />
                    </div>
                  ))}
                </div>
              ) : videos && videos.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left font-medium text-gray-700">Title</th>
                        <th className="px-4 py-3 text-left font-medium text-gray-700">Views</th>
                        <th className="px-4 py-3 text-left font-medium text-gray-700">Date</th>
                        <th className="px-4 py-3 text-left font-medium text-gray-700">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {videos.map((video) => (
                        <tr key={video.id}>
                          <td className="px-4 py-3 font-medium">{video.title}</td>
                          <td className="px-4 py-3">{video.views || 0}</td>
                          <td className="px-4 py-3">
                            {new Date(video.createdAt || Date.now()).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDelete(video.id)}
                                disabled={deleteMutation.isPending}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Video className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">No videos uploaded yet.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
