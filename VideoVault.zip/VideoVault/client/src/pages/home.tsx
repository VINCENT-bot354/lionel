import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import VideoCard from "@/components/video-card";
import type { Video } from "@shared/schema";

export default function Home() {
  const { data: videos, isLoading } = useQuery<Video[]>({
    queryKey: ['/api/videos'],
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center mr-3">
                <div className="w-3 h-3 bg-white rounded-full"></div>
              </div>
              <h1 className="text-xl font-bold text-gray-900">VideoHub</h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-600 hover:text-gray-900 transition-colors">
                Home
              </Link>
              <span className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer">
                Browse
              </span>
              <span className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer">
                About
              </span>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Featured Videos</h2>
          <p className="text-gray-600">Discover and watch amazing video content</p>
        </div>

        {/* Video Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
            {Array.from({ length: 8 }).map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="w-full h-48" />
                <div className="p-4">
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-3 w-20 mb-1" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </Card>
            ))}
          </div>
        ) : videos && videos.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
            {videos.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="text-gray-400 text-6xl mb-4">📹</div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No videos available</h3>
            <p className="text-gray-500">Videos will appear here once they are uploaded.</p>
          </div>
        )}

        {/* Admin Access Link */}
        <div className="fixed bottom-6 right-6">
          <Link href="/admin">
            <Button 
              size="lg"
              className="bg-gray-700 hover:bg-gray-800 text-white p-3 rounded-full shadow-lg transition-colors duration-200"
              title="Authorized Personnel Only"
            >
              <Settings className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">VideoHub</h3>
              <p className="text-gray-300 text-sm">Your premier destination for video content streaming and sharing.</p>
            </div>
            <div>
              <h4 className="font-medium mb-4">Features</h4>
              <ul className="text-gray-300 text-sm space-y-2">
                <li>HD Video Streaming</li>
                <li>Mobile Responsive</li>
                <li>Easy Upload</li>
                <li>Admin Dashboard</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Support</h4>
              <ul className="text-gray-300 text-sm space-y-2">
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Connect</h4>
              <div className="flex space-x-4">
                <span className="text-gray-300 hover:text-white cursor-pointer">Twitter</span>
                <span className="text-gray-300 hover:text-white cursor-pointer">Facebook</span>
                <span className="text-gray-300 hover:text-white cursor-pointer">Instagram</span>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2024 VideoHub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
