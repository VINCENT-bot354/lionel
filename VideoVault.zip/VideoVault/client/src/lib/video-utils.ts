export function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function formatViews(views: number): string {
  if (views >= 1000000) {
    return `${(views / 1000000).toFixed(1)}M`;
  } else if (views >= 1000) {
    return `${(views / 1000).toFixed(1)}K`;
  }
  return views.toString();
}

export function validateVideoFile(file: File): string | null {
  const allowedTypes = ['video/mp4', 'video/webm', 'video/avi', 'video/quicktime'];
  const maxSize = 100 * 1024 * 1024; // 100MB

  if (!allowedTypes.includes(file.type)) {
    return 'Invalid file type. Please upload MP4, WebM, AVI, or MOV files.';
  }

  if (file.size > maxSize) {
    return 'File size too large. Please upload files smaller than 100MB.';
  }

  return null;
}

export function validateImageFile(file: File): string | null {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
  const maxSize = 10 * 1024 * 1024; // 10MB

  if (!allowedTypes.includes(file.type)) {
    return 'Invalid file type. Please upload JPEG, PNG, GIF, or WebP files.';
  }

  if (file.size > maxSize) {
    return 'File size too large. Please upload files smaller than 10MB.';
  }

  return null;
}
