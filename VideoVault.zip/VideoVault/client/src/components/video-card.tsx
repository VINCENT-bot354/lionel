import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Play } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import type { Video } from "@shared/schema";

interface VideoCardProps {
  video: Video;
}

export default function VideoCard({ video }: VideoCardProps) {
  return (
    <Link href={`/video/${video.id}`}>
      <Card className="overflow-hidden hover:shadow-md transition-shadow duration-200 cursor-pointer group">
        <div className="relative">
          {video.thumbnailPath ? (
            <img
              src={`/uploads/thumbnails/${video.thumbnailPath}`}
              alt={video.title}
              className="w-full h-48 object-cover"
            />
          ) : (
            <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
              <Play className="h-12 w-12 text-gray-400" />
            </div>
          )}
          
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-200 flex items-center justify-center">
            <Play className="text-white text-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
          </div>
          
          {video.duration && (
            <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
              {Math.floor(video.duration / 60)}:{(video.duration % 60).toString().padStart(2, '0')}
            </div>
          )}
        </div>
        
        <CardContent className="p-4">
          <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 text-sm">
            {video.title}
          </h3>
          <p className="text-gray-600 text-sm mb-2">
            {video.views || 0} views
          </p>
          <p className="text-gray-500 text-xs">
            {formatDistanceToNow(new Date(video.createdAt || Date.now()), { addSuffix: true })}
          </p>
        </CardContent>
      </Card>
    </Link>
  );
}
