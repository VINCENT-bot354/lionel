import { useState, useRef, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Square, Camera, X } from "lucide-react";

interface VideoRecorderProps {
  onVideoRecorded: (videoBlob: Blob, thumbnailBlob?: Blob) => void;
  onClose: () => void;
}

export default function VideoRecorder({ onVideoRecorded, onClose }: VideoRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [stream, setStream] = useState<MediaStream | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  const startCamera = useCallback(async () => {
    if (stream) return; // Don't start camera if already running
    
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { width: 1280, height: 720 },
        audio: true,
      });
      
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      alert('Could not access camera. Please check permissions.');
    }
  }, [stream]);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  }, [stream]);

  const startRecording = useCallback(() => {
    if (!stream) return;

    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: 'video/webm;codecs=vp8,opus',
    });

    mediaRecorderRef.current = mediaRecorder;
    recordedChunksRef.current = [];

    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        recordedChunksRef.current.push(event.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
      onVideoRecorded(blob);
      recordedChunksRef.current = [];
    };

    mediaRecorder.start();
    setIsRecording(true);
    setRecordingTime(0);

    intervalRef.current = setInterval(() => {
      setRecordingTime(prev => prev + 1);
    }, 1000);
  }, [stream, onVideoRecorded]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
  }, [isRecording]);

  const captureThumbnail = useCallback(() => {
    if (!videoRef.current) return;

    const canvas = document.createElement('canvas');
    const video = videoRef.current;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0);
      
      canvas.toBlob((blob) => {
        if (blob) {
          // Create a new video blob with the thumbnail
          const videoBlob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
          onVideoRecorded(videoBlob, blob);
        }
      }, 'image/png');
    }
  }, [onVideoRecorded]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Initialize camera when component mounts
  useEffect(() => {
    let isMounted = true;
    
    const initCamera = async () => {
      if (!isMounted) return;
      
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { width: 1280, height: 720 },
          audio: true,
        });
        
        if (isMounted) {
          setStream(mediaStream);
          if (videoRef.current) {
            videoRef.current.srcObject = mediaStream;
          }
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        if (isMounted) {
          alert('Could not access camera. Please check permissions.');
        }
      }
    };
    
    initCamera();
    
    return () => {
      isMounted = false;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []); // Empty dependency array to run only once on mount

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Video Recorder</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Video Preview */}
        <div className="relative bg-gray-900 rounded-lg overflow-hidden mb-4">
          <video
            ref={videoRef}
            className="w-full h-64 bg-gray-800"
            autoPlay
            muted
            playsInline
          />
          
          {isRecording && (
            <div className="absolute top-2 left-2 bg-red-600 text-white px-2 py-1 rounded text-sm flex items-center">
              <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
              REC {formatTime(recordingTime)}
            </div>
          )}

          <div className="absolute bottom-2 right-2 flex space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={captureThumbnail}
              disabled={!stream}
              className="bg-white/20 hover:bg-white/30 text-white"
            >
              <Camera className="h-4 w-4 mr-1" />
              Capture
            </Button>
          </div>
        </div>

        {/* Recording Controls */}
        <div className="flex space-x-3">
          <Button
            onClick={startRecording}
            disabled={isRecording || !stream}
            className="flex-1 bg-red-600 hover:bg-red-700"
          >
            <Play className="h-4 w-4 mr-2" />
            Start Recording
          </Button>
          
          <Button
            onClick={stopRecording}
            disabled={!isRecording}
            variant="secondary"
            className="flex-1"
          >
            <Square className="h-4 w-4 mr-2" />
            Stop Recording
          </Button>
        </div>

        {!stream && (
          <div className="mt-4 text-center text-gray-500">
            <p>Please allow camera access to start recording</p>
            <Button onClick={startCamera} className="mt-2">
              Enable Camera
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
