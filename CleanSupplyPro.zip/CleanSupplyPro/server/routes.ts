import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import multer from "multer";
import path from "path";
import { 
  insertAdminUserSchema, insertSiteConfigSchema, insertPageSchema,
  insertServiceSchema, insertProductSchema, insertArticleSchema,
  insertTestimonialSchema, insertContactInfoSchema, insertSocialLinkSchema,
  insertUpdateBannerSchema, insertContactSubmissionSchema, insertMenuItemSchema,
  insertEmailSettingsSchema, insertTermsOfServiceSchema
} from "@shared/schema";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|mp4|webm|pdf/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

// Auth middleware
const authenticateAdmin = async (req: any, res: any, next: any) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ message: 'Access denied. No token provided.' });
    }

    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const admin = await storage.getAdminUser(decoded.id);
    
    if (!admin || !admin.isActive) {
      return res.status(401).json({ message: 'Invalid token' });
    }

    req.admin = admin;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      const admin = await storage.getAdminUserByUsername(username);
      if (!admin || !admin.isActive) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await bcrypt.compare(password, admin.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign({ id: admin.id }, JWT_SECRET, { expiresIn: '24h' });
      
      res.json({ 
        token, 
        admin: { 
          id: admin.id, 
          username: admin.username, 
          email: admin.email 
        } 
      });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertAdminUserSchema.parse(req.body);
      
      const existingAdmin = await storage.getAdminUserByUsername(validatedData.username);
      if (existingAdmin) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const hashedPassword = await bcrypt.hash(validatedData.password, 10);
      const admin = await storage.createAdminUser({
        ...validatedData,
        password: hashedPassword
      });

      res.status(201).json({ 
        admin: { 
          id: admin.id, 
          username: admin.username, 
          email: admin.email 
        } 
      });
    } catch (error) {
      res.status(400).json({ message: "Registration failed", error });
    }
  });

  // Public API routes
  
  // Site config
  app.get("/api/site-config", async (req, res) => {
    try {
      const config = await storage.getSiteConfig();
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch site config" });
    }
  });

  // Pages
  app.get("/api/pages/:slug", async (req, res) => {
    try {
      const page = await storage.getPage(req.params.slug);
      if (!page || !page.isPublished) {
        return res.status(404).json({ message: "Page not found" });
      }
      res.json(page);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch page" });
    }
  });

  // Services
  app.get("/api/services", async (req, res) => {
    try {
      const services = await storage.getActiveServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  // Products
  app.get("/api/products", async (req, res) => {
    try {
      const { featured } = req.query;
      const products = featured === 'true' 
        ? await storage.getFeaturedProducts()
        : await storage.getActiveProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Articles (News & Blog)
  app.get("/api/articles", async (req, res) => {
    try {
      const { type } = req.query;
      const articles = await storage.getPublishedArticles(type as string);
      res.json(articles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  app.get("/api/articles/:slug", async (req, res) => {
    try {
      const article = await storage.getArticleBySlug(req.params.slug);
      if (!article || !article.isPublished) {
        return res.status(404).json({ message: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch article" });
    }
  });

  // Testimonials
  app.get("/api/testimonials", async (req, res) => {
    try {
      const testimonials = await storage.getActiveTestimonials();
      res.json(testimonials);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });

  // Contact info
  app.get("/api/contact-info", async (req, res) => {
    try {
      const info = await storage.getContactInfo();
      res.json(info);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contact info" });
    }
  });

  // Social links
  app.get("/api/social-links", async (req, res) => {
    try {
      const links = await storage.getActiveSocialLinks();
      res.json(links);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch social links" });
    }
  });

  // Update banners
  app.get("/api/banners", async (req, res) => {
    try {
      const banners = await storage.getActiveBanners();
      res.json(banners);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch banners" });
    }
  });

  // Menu items
  app.get("/api/menu-items", async (req, res) => {
    try {
      const items = await storage.getActiveMenuItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch menu items" });
    }
  });

  // Terms of service
  app.get("/api/terms-of-service", async (req, res) => {
    try {
      const terms = await storage.getTermsOfService();
      res.json(terms);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch terms of service" });
    }
  });

  // Email settings (public route for fetching main email)
  app.get("/api/email-settings", async (req, res) => {
    try {
      const settings = await storage.getEmailSettings();
      // Only return public fields
      if (settings) {
        res.json({
          fromEmail: settings.fromEmail,
          fromName: settings.fromName
        });
      } else {
        res.json(null);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch email settings" });
    }
  });

  // Contact form submission
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      const submission = await storage.createContactSubmission(validatedData);
      res.status(201).json({ message: "Message sent successfully" });
    } catch (error) {
      res.status(400).json({ message: "Failed to send message", error });
    }
  });

  // Admin routes (protected)
  
  // Site config management
  app.put("/api/admin/site-config", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertSiteConfigSchema.parse(req.body);
      const config = await storage.updateSiteConfig(validatedData);
      res.json(config);
    } catch (error) {
      res.status(400).json({ message: "Failed to update site config", error });
    }
  });

  // Pages management
  app.get("/api/admin/pages", authenticateAdmin, async (req, res) => {
    try {
      const pages = await storage.getAllPages();
      res.json(pages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pages" });
    }
  });

  app.post("/api/admin/pages", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertPageSchema.parse(req.body);
      const page = await storage.createPage(validatedData);
      res.status(201).json(page);
    } catch (error) {
      res.status(400).json({ message: "Failed to create page", error });
    }
  });

  app.put("/api/admin/pages/:slug", authenticateAdmin, async (req, res) => {
    try {
      const page = await storage.updatePage(req.params.slug, req.body);
      res.json(page);
    } catch (error) {
      res.status(400).json({ message: "Failed to update page", error });
    }
  });

  app.delete("/api/admin/pages/:slug", authenticateAdmin, async (req, res) => {
    try {
      await storage.deletePage(req.params.slug);
      res.json({ message: "Page deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete page" });
    }
  });

  // Services management
  app.get("/api/admin/services", authenticateAdmin, async (req, res) => {
    try {
      const services = await storage.getAllServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  app.post("/api/admin/services", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertServiceSchema.parse(req.body);
      const service = await storage.createService(validatedData);
      res.status(201).json(service);
    } catch (error) {
      res.status(400).json({ message: "Failed to create service", error });
    }
  });

  app.put("/api/admin/services/:id", authenticateAdmin, async (req, res) => {
    try {
      const service = await storage.updateService(req.params.id, req.body);
      res.json(service);
    } catch (error) {
      res.status(400).json({ message: "Failed to update service", error });
    }
  });

  app.delete("/api/admin/services/:id", authenticateAdmin, async (req, res) => {
    try {
      await storage.deleteService(req.params.id);
      res.json({ message: "Service deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete service" });
    }
  });

  // Products management
  app.get("/api/admin/products", authenticateAdmin, async (req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.post("/api/admin/products", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error) {
      res.status(400).json({ message: "Failed to create product", error });
    }
  });

  app.put("/api/admin/products/:id", authenticateAdmin, async (req, res) => {
    try {
      const product = await storage.updateProduct(req.params.id, req.body);
      res.json(product);
    } catch (error) {
      res.status(400).json({ message: "Failed to update product", error });
    }
  });

  app.delete("/api/admin/products/:id", authenticateAdmin, async (req, res) => {
    try {
      await storage.deleteProduct(req.params.id);
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Articles management
  app.get("/api/admin/articles", authenticateAdmin, async (req, res) => {
    try {
      const { type } = req.query;
      const articles = await storage.getAllArticles(type as string);
      res.json(articles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  app.post("/api/admin/articles", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertArticleSchema.parse(req.body);
      const article = await storage.createArticle(validatedData);
      res.status(201).json(article);
    } catch (error) {
      res.status(400).json({ message: "Failed to create article", error });
    }
  });

  app.put("/api/admin/articles/:id", authenticateAdmin, async (req, res) => {
    try {
      const article = await storage.updateArticle(req.params.id, req.body);
      res.json(article);
    } catch (error) {
      res.status(400).json({ message: "Failed to update article", error });
    }
  });

  app.delete("/api/admin/articles/:id", authenticateAdmin, async (req, res) => {
    try {
      await storage.deleteArticle(req.params.id);
      res.json({ message: "Article deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete article" });
    }
  });

  // Testimonials management
  app.get("/api/admin/testimonials", authenticateAdmin, async (req, res) => {
    try {
      const testimonials = await storage.getAllTestimonials();
      res.json(testimonials);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });

  app.post("/api/admin/testimonials", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertTestimonialSchema.parse(req.body);
      const testimonial = await storage.createTestimonial(validatedData);
      res.status(201).json(testimonial);
    } catch (error) {
      res.status(400).json({ message: "Failed to create testimonial", error });
    }
  });

  app.put("/api/admin/testimonials/:id", authenticateAdmin, async (req, res) => {
    try {
      const testimonial = await storage.updateTestimonial(req.params.id, req.body);
      res.json(testimonial);
    } catch (error) {
      res.status(400).json({ message: "Failed to update testimonial", error });
    }
  });

  app.delete("/api/admin/testimonials/:id", authenticateAdmin, async (req, res) => {
    try {
      await storage.deleteTestimonial(req.params.id);
      res.json({ message: "Testimonial deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete testimonial" });
    }
  });

  // Contact info management
  app.get("/api/admin/contact-info", authenticateAdmin, async (req, res) => {
    try {
      const info = await storage.getContactInfo();
      res.json(info);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contact info" });
    }
  });

  app.put("/api/admin/contact-info", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertContactInfoSchema.parse(req.body);
      const info = await storage.updateContactInfo(validatedData);
      res.json(info);
    } catch (error) {
      res.status(400).json({ message: "Failed to update contact info", error });
    }
  });

  // Social links management
  app.get("/api/admin/social-links", authenticateAdmin, async (req, res) => {
    try {
      const links = await storage.getAllSocialLinks();
      res.json(links);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch social links" });
    }
  });

  app.post("/api/admin/social-links", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertSocialLinkSchema.parse(req.body);
      const link = await storage.createSocialLink(validatedData);
      res.status(201).json(link);
    } catch (error) {
      res.status(400).json({ message: "Failed to create social link", error });
    }
  });

  app.put("/api/admin/social-links/:id", authenticateAdmin, async (req, res) => {
    try {
      const link = await storage.updateSocialLink(req.params.id, req.body);
      res.json(link);
    } catch (error) {
      res.status(400).json({ message: "Failed to update social link", error });
    }
  });

  app.delete("/api/admin/social-links/:id", authenticateAdmin, async (req, res) => {
    try {
      await storage.deleteSocialLink(req.params.id);
      res.json({ message: "Social link deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete social link" });
    }
  });

  // Update banners management
  app.get("/api/admin/banners", authenticateAdmin, async (req, res) => {
    try {
      const banners = await storage.getAllBanners();
      res.json(banners);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch banners" });
    }
  });

  app.post("/api/admin/banners", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertUpdateBannerSchema.parse(req.body);
      const banner = await storage.createBanner(validatedData);
      res.status(201).json(banner);
    } catch (error) {
      res.status(400).json({ message: "Failed to create banner", error });
    }
  });

  app.put("/api/admin/banners/:id", authenticateAdmin, async (req, res) => {
    try {
      const banner = await storage.updateBanner(req.params.id, req.body);
      res.json(banner);
    } catch (error) {
      res.status(400).json({ message: "Failed to update banner", error });
    }
  });

  app.delete("/api/admin/banners/:id", authenticateAdmin, async (req, res) => {
    try {
      await storage.deleteBanner(req.params.id);
      res.json({ message: "Banner deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete banner" });
    }
  });

  // Contact submissions
  app.get("/api/admin/contact-submissions", authenticateAdmin, async (req, res) => {
    try {
      const submissions = await storage.getAllContactSubmissions();
      res.json(submissions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contact submissions" });
    }
  });

  app.patch("/api/admin/contact-submissions/:id/read", authenticateAdmin, async (req, res) => {
    try {
      await storage.markSubmissionAsRead(req.params.id);
      res.json({ message: "Submission marked as read" });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark submission as read" });
    }
  });

  // Password change
  app.put("/api/admin/change-password", authenticateAdmin, async (req, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current password and new password are required" });
      }

      const admin = await storage.getAdminUser((req as any).admin.id);
      if (!admin) {
        return res.status(404).json({ message: "Admin user not found" });
      }

      const isValidPassword = await bcrypt.compare(currentPassword, admin.password);
      if (!isValidPassword) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }

      const hashedNewPassword = await bcrypt.hash(newPassword, 10);
      await storage.updateAdminPassword((req as any).admin.id, hashedNewPassword);
      
      res.json({ message: "Password updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update password" });
    }
  });

  // Menu items management
  app.get("/api/admin/menu-items", authenticateAdmin, async (req, res) => {
    try {
      const items = await storage.getAllMenuItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch menu items" });
    }
  });

  app.post("/api/admin/menu-items", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertMenuItemSchema.parse(req.body);
      const item = await storage.createMenuItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      res.status(400).json({ message: "Failed to create menu item", error });
    }
  });

  app.put("/api/admin/menu-items/:id", authenticateAdmin, async (req, res) => {
    try {
      const item = await storage.updateMenuItem(req.params.id, req.body);
      res.json(item);
    } catch (error) {
      res.status(400).json({ message: "Failed to update menu item", error });
    }
  });

  app.delete("/api/admin/menu-items/:id", authenticateAdmin, async (req, res) => {
    try {
      await storage.deleteMenuItem(req.params.id);
      res.json({ message: "Menu item deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete menu item" });
    }
  });

  // Email settings management (admin)
  app.get("/api/admin/email-settings", authenticateAdmin, async (req, res) => {
    try {
      const settings = await storage.getEmailSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch email settings" });
    }
  });

  app.put("/api/admin/email-settings", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertEmailSettingsSchema.parse(req.body);
      const settings = await storage.updateEmailSettings(validatedData);
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: "Failed to update email settings", error });
    }
  });

  // Terms of service management (admin)
  app.get("/api/admin/terms-of-service", authenticateAdmin, async (req, res) => {
    try {
      const terms = await storage.getTermsOfService();
      res.json(terms);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch terms of service" });
    }
  });

  app.put("/api/admin/terms-of-service", authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertTermsOfServiceSchema.parse(req.body);
      const terms = await storage.updateTermsOfService(validatedData);
      res.json(terms);
    } catch (error) {
      res.status(400).json({ message: "Failed to update terms of service", error });
    }
  });

  // File upload (single file - legacy)
  app.post("/api/admin/upload", authenticateAdmin, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // In a real application, you would upload to a cloud storage service
      // For now, return the file path
      const fileUrl = `/uploads/${req.file.filename}`;
      res.json({ url: fileUrl });
    } catch (error) {
      res.status(500).json({ message: "File upload failed", error });
    }
  });

  // Multiple images upload
  app.post("/api/admin/upload/images", authenticateAdmin, upload.array('images', 10), async (req, res) => {
    try {
      if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
        return res.status(400).json({ message: "No images uploaded" });
      }

      const uploadedImages = req.files.map(file => ({
        id: file.filename,
        filename: file.filename,
        originalName: file.originalname,
        url: `/uploads/${file.filename}`,
        size: file.size,
        mimetype: file.mimetype,
        uploadedAt: new Date().toISOString()
      }));

      // Store image metadata in database
      for (const image of uploadedImages) {
        await storage.createImage(image);
      }

      res.json({ 
        message: "Images uploaded successfully", 
        uploaded: uploadedImages 
      });
    } catch (error) {
      res.status(500).json({ message: "Image upload failed", error });
    }
  });

  // Get all images
  app.get("/api/admin/images", authenticateAdmin, async (req, res) => {
    try {
      const images = await storage.getAllImages();
      res.json(images);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch images" });
    }
  });

  // Delete image
  app.delete("/api/admin/images/:id", authenticateAdmin, async (req, res) => {
    try {
      await storage.deleteImage(req.params.id);
      res.json({ message: "Image deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete image" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
