import { 
  AdminUser, InsertAdminUser,
  SiteConfig, InsertSiteConfig,
  Page, InsertPage,
  Service, InsertService,
  Product, InsertProduct,
  Article, InsertArticle,
  Testimonial, InsertTestimonial,
  ContactInfo, InsertContactInfo,
  SocialLink, InsertSocialLink,
  UpdateBanner, InsertUpdateBanner,
  ContactSubmission, InsertContactSubmission,
  MenuItem, InsertMenuItem,
  EmailSettings, InsertEmailSettings,
  TermsOfService, InsertTermsOfService,
  Image, InsertImage,
  adminUsers, siteConfig, pages, services, products, articles,
  testimonials, contactInfo, socialLinks, updateBanners,
  contactSubmissions, menuItems, emailSettings, termsOfService, images
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // Admin users
  getAdminUser(id: string): Promise<AdminUser | undefined>;
  getAdminUserByUsername(username: string): Promise<AdminUser | undefined>;
  createAdminUser(user: InsertAdminUser): Promise<AdminUser>;
  updateAdminPassword(adminId: string, hashedPassword: string): Promise<void>;

  // Site config
  getSiteConfig(): Promise<SiteConfig | undefined>;
  updateSiteConfig(config: InsertSiteConfig): Promise<SiteConfig>;

  // Pages
  getPage(slug: string): Promise<Page | undefined>;
  getAllPages(): Promise<Page[]>;
  createPage(page: InsertPage): Promise<Page>;
  updatePage(slug: string, page: Partial<InsertPage>): Promise<Page>;
  deletePage(slug: string): Promise<void>;

  // Services
  getAllServices(): Promise<Service[]>;
  getActiveServices(): Promise<Service[]>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: string, service: Partial<InsertService>): Promise<Service>;
  deleteService(id: string): Promise<void>;

  // Products
  getAllProducts(): Promise<Product[]>;
  getActiveProducts(): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: string): Promise<void>;

  // Articles
  getAllArticles(type?: string): Promise<Article[]>;
  getPublishedArticles(type?: string): Promise<Article[]>;
  getArticleBySlug(slug: string): Promise<Article | undefined>;
  createArticle(article: InsertArticle): Promise<Article>;
  updateArticle(id: string, article: Partial<InsertArticle>): Promise<Article>;
  deleteArticle(id: string): Promise<void>;

  // Testimonials
  getAllTestimonials(): Promise<Testimonial[]>;
  getActiveTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  updateTestimonial(id: string, testimonial: Partial<InsertTestimonial>): Promise<Testimonial>;
  deleteTestimonial(id: string): Promise<void>;

  // Contact info
  getContactInfo(): Promise<ContactInfo | undefined>;
  updateContactInfo(info: InsertContactInfo): Promise<ContactInfo>;

  // Social links
  getAllSocialLinks(): Promise<SocialLink[]>;
  getActiveSocialLinks(): Promise<SocialLink[]>;
  createSocialLink(link: InsertSocialLink): Promise<SocialLink>;
  updateSocialLink(id: string, link: Partial<InsertSocialLink>): Promise<SocialLink>;
  deleteSocialLink(id: string): Promise<void>;

  // Update banners
  getActiveBanners(): Promise<UpdateBanner[]>;
  getAllBanners(): Promise<UpdateBanner[]>;
  createBanner(banner: InsertUpdateBanner): Promise<UpdateBanner>;
  updateBanner(id: string, banner: Partial<InsertUpdateBanner>): Promise<UpdateBanner>;
  deleteBanner(id: string): Promise<void>;

  // Contact submissions
  getAllContactSubmissions(): Promise<ContactSubmission[]>;
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  markSubmissionAsRead(id: string): Promise<void>;

  // Menu items
  getAllMenuItems(): Promise<MenuItem[]>;
  getActiveMenuItems(): Promise<MenuItem[]>;
  createMenuItem(item: InsertMenuItem): Promise<MenuItem>;
  updateMenuItem(id: string, item: Partial<InsertMenuItem>): Promise<MenuItem>;
  deleteMenuItem(id: string): Promise<void>;

  // Email settings
  getEmailSettings(): Promise<EmailSettings | undefined>;
  updateEmailSettings(settings: InsertEmailSettings): Promise<EmailSettings>;

  // Terms of service
  getTermsOfService(): Promise<TermsOfService | undefined>;
  updateTermsOfService(terms: InsertTermsOfService): Promise<TermsOfService>;

  // Images
  getAllImages(): Promise<Image[]>;
  createImage(image: InsertImage): Promise<Image>;
  deleteImage(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Admin users
  async getAdminUser(id: string): Promise<AdminUser | undefined> {
    const [user] = await db.select().from(adminUsers).where(eq(adminUsers.id, id));
    return user || undefined;
  }

  async getAdminUserByUsername(username: string): Promise<AdminUser | undefined> {
    const [user] = await db.select().from(adminUsers).where(eq(adminUsers.username, username));
    return user || undefined;
  }

  async createAdminUser(user: InsertAdminUser): Promise<AdminUser> {
    const [newUser] = await db.insert(adminUsers).values(user).returning();
    return newUser;
  }

  async updateAdminPassword(adminId: string, hashedPassword: string): Promise<void> {
    await db.update(adminUsers)
      .set({ password: hashedPassword })
      .where(eq(adminUsers.id, adminId));
  }

  // Site config
  async getSiteConfig(): Promise<SiteConfig | undefined> {
    const [config] = await db.select().from(siteConfig).limit(1);
    return config || undefined;
  }

  async updateSiteConfig(config: InsertSiteConfig): Promise<SiteConfig> {
    const existing = await this.getSiteConfig();
    if (existing) {
      const [updated] = await db.update(siteConfig)
        .set({ ...config, updatedAt: new Date() })
        .where(eq(siteConfig.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(siteConfig).values(config).returning();
      return created;
    }
  }

  // Pages
  async getPage(slug: string): Promise<Page | undefined> {
    const [page] = await db.select().from(pages).where(eq(pages.slug, slug));
    return page || undefined;
  }

  async getAllPages(): Promise<Page[]> {
    return await db.select().from(pages).orderBy(pages.title);
  }

  async createPage(page: InsertPage): Promise<Page> {
    const [newPage] = await db.insert(pages).values(page).returning();
    return newPage;
  }

  async updatePage(slug: string, pageData: Partial<InsertPage>): Promise<Page> {
    const [updated] = await db.update(pages)
      .set({ ...pageData, updatedAt: new Date() })
      .where(eq(pages.slug, slug))
      .returning();
    return updated;
  }

  async deletePage(slug: string): Promise<void> {
    await db.delete(pages).where(eq(pages.slug, slug));
  }

  // Services
  async getAllServices(): Promise<Service[]> {
    return await db.select().from(services).orderBy(services.order);
  }

  async getActiveServices(): Promise<Service[]> {
    return await db.select().from(services)
      .where(eq(services.isActive, true))
      .orderBy(services.order);
  }

  async createService(service: InsertService): Promise<Service> {
    const [newService] = await db.insert(services).values(service).returning();
    return newService;
  }

  async updateService(id: string, serviceData: Partial<InsertService>): Promise<Service> {
    const [updated] = await db.update(services)
      .set(serviceData)
      .where(eq(services.id, id))
      .returning();
    return updated;
  }

  async deleteService(id: string): Promise<void> {
    await db.delete(services).where(eq(services.id, id));
  }

  // Products
  async getAllProducts(): Promise<Product[]> {
    return await db.select().from(products).orderBy(products.order);
  }

  async getActiveProducts(): Promise<Product[]> {
    return await db.select().from(products)
      .where(eq(products.isActive, true))
      .orderBy(products.order);
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return await db.select().from(products)
      .where(and(eq(products.isActive, true), eq(products.isFeatured, true)))
      .orderBy(products.order);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: string, productData: Partial<InsertProduct>): Promise<Product> {
    const [updated] = await db.update(products)
      .set(productData)
      .where(eq(products.id, id))
      .returning();
    return updated;
  }

  async deleteProduct(id: string): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  // Articles
  async getAllArticles(type?: string): Promise<Article[]> {
    const query = db.select().from(articles);
    if (type) {
      return await query.where(eq(articles.type, type)).orderBy(desc(articles.publishedAt));
    }
    return await query.orderBy(desc(articles.publishedAt));
  }

  async getPublishedArticles(type?: string): Promise<Article[]> {
    if (type) {
      return await db.select().from(articles)
        .where(and(eq(articles.isPublished, true), eq(articles.type, type)))
        .orderBy(desc(articles.publishedAt));
    }
    return await db.select().from(articles)
      .where(eq(articles.isPublished, true))
      .orderBy(desc(articles.publishedAt));
  }

  async getArticleBySlug(slug: string): Promise<Article | undefined> {
    const [article] = await db.select().from(articles).where(eq(articles.slug, slug));
    return article || undefined;
  }

  async createArticle(article: InsertArticle): Promise<Article> {
    const [newArticle] = await db.insert(articles).values(article).returning();
    return newArticle;
  }

  async updateArticle(id: string, articleData: Partial<InsertArticle>): Promise<Article> {
    const [updated] = await db.update(articles)
      .set(articleData)
      .where(eq(articles.id, id))
      .returning();
    return updated;
  }

  async deleteArticle(id: string): Promise<void> {
    await db.delete(articles).where(eq(articles.id, id));
  }

  // Testimonials
  async getAllTestimonials(): Promise<Testimonial[]> {
    return await db.select().from(testimonials).orderBy(testimonials.order);
  }

  async getActiveTestimonials(): Promise<Testimonial[]> {
    return await db.select().from(testimonials)
      .where(eq(testimonials.isActive, true))
      .orderBy(testimonials.order);
  }

  async createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial> {
    const [newTestimonial] = await db.insert(testimonials).values(testimonial).returning();
    return newTestimonial;
  }

  async updateTestimonial(id: string, testimonialData: Partial<InsertTestimonial>): Promise<Testimonial> {
    const [updated] = await db.update(testimonials)
      .set(testimonialData)
      .where(eq(testimonials.id, id))
      .returning();
    return updated;
  }

  async deleteTestimonial(id: string): Promise<void> {
    await db.delete(testimonials).where(eq(testimonials.id, id));
  }

  // Contact info
  async getContactInfo(): Promise<ContactInfo | undefined> {
    const [info] = await db.select().from(contactInfo).limit(1);
    return info || undefined;
  }

  async updateContactInfo(info: InsertContactInfo): Promise<ContactInfo> {
    const existing = await this.getContactInfo();
    if (existing) {
      const [updated] = await db.update(contactInfo)
        .set({ ...info, updatedAt: new Date() })
        .where(eq(contactInfo.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(contactInfo).values(info).returning();
      return created;
    }
  }

  // Social links
  async getAllSocialLinks(): Promise<SocialLink[]> {
    return await db.select().from(socialLinks).orderBy(socialLinks.order);
  }

  async getActiveSocialLinks(): Promise<SocialLink[]> {
    return await db.select().from(socialLinks)
      .where(eq(socialLinks.isActive, true))
      .orderBy(socialLinks.order);
  }

  async createSocialLink(link: InsertSocialLink): Promise<SocialLink> {
    const [newLink] = await db.insert(socialLinks).values(link).returning();
    return newLink;
  }

  async updateSocialLink(id: string, linkData: Partial<InsertSocialLink>): Promise<SocialLink> {
    const [updated] = await db.update(socialLinks)
      .set(linkData)
      .where(eq(socialLinks.id, id))
      .returning();
    return updated;
  }

  async deleteSocialLink(id: string): Promise<void> {
    await db.delete(socialLinks).where(eq(socialLinks.id, id));
  }

  // Update banners
  async getActiveBanners(): Promise<UpdateBanner[]> {
    const now = new Date();
    return await db.select().from(updateBanners)
      .where(
        and(
          eq(updateBanners.isActive, true),
          // Banner should be active if no end date or end date is in future
        )
      );
  }

  async getAllBanners(): Promise<UpdateBanner[]> {
    return await db.select().from(updateBanners).orderBy(desc(updateBanners.createdAt));
  }

  async createBanner(banner: InsertUpdateBanner): Promise<UpdateBanner> {
    const [newBanner] = await db.insert(updateBanners).values(banner).returning();
    return newBanner;
  }

  async updateBanner(id: string, bannerData: Partial<InsertUpdateBanner>): Promise<UpdateBanner> {
    const [updated] = await db.update(updateBanners)
      .set(bannerData)
      .where(eq(updateBanners.id, id))
      .returning();
    return updated;
  }

  async deleteBanner(id: string): Promise<void> {
    await db.delete(updateBanners).where(eq(updateBanners.id, id));
  }

  // Contact submissions
  async getAllContactSubmissions(): Promise<ContactSubmission[]> {
    return await db.select().from(contactSubmissions).orderBy(desc(contactSubmissions.createdAt));
  }

  async createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission> {
    const [newSubmission] = await db.insert(contactSubmissions).values(submission).returning();
    return newSubmission;
  }

  async markSubmissionAsRead(id: string): Promise<void> {
    await db.update(contactSubmissions)
      .set({ isRead: true })
      .where(eq(contactSubmissions.id, id));
  }

  // Menu items
  async getAllMenuItems(): Promise<MenuItem[]> {
    return await db.select().from(menuItems).orderBy(menuItems.order);
  }

  async getActiveMenuItems(): Promise<MenuItem[]> {
    return await db.select().from(menuItems)
      .where(eq(menuItems.isActive, true))
      .orderBy(menuItems.order);
  }

  async createMenuItem(item: InsertMenuItem): Promise<MenuItem> {
    const [newItem] = await db.insert(menuItems).values(item).returning();
    return newItem;
  }

  async updateMenuItem(id: string, itemData: Partial<InsertMenuItem>): Promise<MenuItem> {
    const [updated] = await db.update(menuItems)
      .set(itemData)
      .where(eq(menuItems.id, id))
      .returning();
    return updated;
  }

  async deleteMenuItem(id: string): Promise<void> {
    await db.delete(menuItems).where(eq(menuItems.id, id));
  }

  // Email settings
  async getEmailSettings(): Promise<EmailSettings | undefined> {
    const [settings] = await db.select().from(emailSettings).limit(1);
    return settings || undefined;
  }

  async updateEmailSettings(settingsData: InsertEmailSettings): Promise<EmailSettings> {
    const existing = await this.getEmailSettings();
    if (existing) {
      const [updated] = await db.update(emailSettings)
        .set({ ...settingsData, updatedAt: new Date() })
        .where(eq(emailSettings.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(emailSettings).values(settingsData).returning();
      return created;
    }
  }

  // Terms of service
  async getTermsOfService(): Promise<TermsOfService | undefined> {
    const [terms] = await db.select().from(termsOfService)
      .where(eq(termsOfService.isActive, true))
      .limit(1);
    return terms || undefined;
  }

  async updateTermsOfService(termsData: InsertTermsOfService): Promise<TermsOfService> {
    const existing = await this.getTermsOfService();
    if (existing) {
      const [updated] = await db.update(termsOfService)
        .set({ ...termsData, lastUpdated: new Date() })
        .where(eq(termsOfService.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(termsOfService).values({
        ...termsData,
        isActive: true
      }).returning();
      return created;
    }
  }

  // Images
  async getAllImages(): Promise<Image[]> {
    return await db.select().from(images).orderBy(desc(images.uploadedAt));
  }

  async createImage(image: InsertImage): Promise<Image> {
    const [newImage] = await db.insert(images).values(image).returning();
    return newImage;
  }

  async deleteImage(id: string): Promise<void> {
    await db.delete(images).where(eq(images.id, id));
  }
}

export const storage = new DatabaseStorage();