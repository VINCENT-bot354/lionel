
import bcrypt from "bcrypt";
import { storage } from "./storage";

export async function initializeDefaultAdmin() {
  try {
    // Check if admin user already exists
    const existingAdmin = await storage.getAdminUserByUsername("admin");
    
    if (!existingAdmin) {
      // Create default admin user
      const hashedPassword = await bcrypt.hash("admin123", 10);
      
      await storage.createAdminUser({
        username: "admin",
        email: "admin@mmcleaners.com",
        password: hashedPassword,
        isActive: true
      });
      
      console.log("✅ Default admin user created successfully");
      console.log("Username: admin");
      console.log("Password: admin123");
    } else {
      console.log("ℹ️ Default admin user already exists");
    }
  } catch (error) {
    console.error("❌ Error initializing default admin user:", error);
  }
}
