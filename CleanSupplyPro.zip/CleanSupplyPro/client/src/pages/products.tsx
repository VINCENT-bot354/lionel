import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import UpdateBanner from "@/components/ui/update-banner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ShoppingCart, Star, Filter } from "lucide-react";

interface Product {
  id: string;
  name: string;
  description: string;
  price: string;
  image?: string;
  category?: string;
  isActive: boolean;
  isFeatured: boolean;
  order: number;
}

export default function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const activeProducts = products.filter(product => product.isActive).sort((a, b) => a.order - b.order);

  // Default products if none in database
  const defaultProducts = [
    {
      id: "hand-wash-premium",
      name: "Premium Hand Wash",
      description: "Antibacterial formula with moisturizing agents. Gentle on skin while providing superior cleaning power.",
      price: "$12.99",
      category: "Hand Care",
      image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      isFeatured: true
    },
    {
      id: "all-purpose-cleaner",
      name: "All-Purpose Cleaner",
      description: "Multi-surface cleaning solution effective on glass, wood, metal, and plastic surfaces.",
      price: "$8.99",
      category: "Cleaners",
      image: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      isFeatured: true
    },
    {
      id: "microfiber-cloths",
      name: "Microfiber Cloths",
      description: "Professional-grade cleaning cloths that capture dirt and bacteria. Pack of 12 assorted colors.",
      price: "$24.99",
      category: "Equipment",
      image: "https://images.unsplash.com/photo-1628177142898-93e36e4e3a50?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      isFeatured: false
    },
    {
      id: "sanitizer-spray",
      name: "Sanitizer Spray",
      description: "Hospital-grade disinfectant spray effective against viruses and bacteria. EPA approved.",
      price: "$15.99",
      category: "Sanitizers",
      image: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      isFeatured: true
    },
    {
      id: "glass-cleaner",
      name: "Professional Glass Cleaner",
      description: "Streak-free formula for windows, mirrors, and glass surfaces. Ammonia-free and eco-friendly.",
      price: "$9.99",
      category: "Cleaners",
      image: "https://images.unsplash.com/photo-1563453392212-326f5e854473?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      isFeatured: false
    },
    {
      id: "floor-cleaner",
      name: "Multi-Surface Floor Cleaner",
      description: "Safe for hardwood, tile, laminate, and vinyl flooring. Leaves no residue and dries quickly.",
      price: "$11.99",
      category: "Cleaners",
      image: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      isFeatured: false
    }
  ];

  const displayProducts = activeProducts.length > 0 ? activeProducts : defaultProducts;
  
  // Get unique categories
  const categories = ["all", ...Array.from(new Set(displayProducts.map(p => p.category).filter(Boolean)))];
  
  // Filter products by category
  const filteredProducts = selectedCategory === "all" 
    ? displayProducts 
    : displayProducts.filter(p => p.category === selectedCategory);

  const featuredProducts = filteredProducts.filter(p => p.isFeatured);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <UpdateBanner />
        <Navbar />
        <div className="container mx-auto px-4 py-20">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="loading-shimmer h-96"></Card>
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UpdateBanner />
      <Navbar />
      
      {/* Hero Section */}
      <section className="jungle-gradient text-white py-20" data-testid="products-hero">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6" data-testid="text-products-hero-title">
              Premium Cleaning Products
            </h1>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto" data-testid="text-products-hero-subtitle">
              Professional-grade cleaning supplies trusted by commercial and residential clients. Eco-friendly formulations that deliver exceptional results while protecting your health and the environment.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <section className="py-20 bg-white" data-testid="featured-products">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-featured-title">
                Featured Products
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-featured-subtitle">
                Our most popular and highly-rated cleaning products
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {featuredProducts.slice(0, 4).map((product) => (
                <Card key={product.id} className="card-hover relative" data-testid={`card-featured-product-${product.id}`}>
                  <Badge className="absolute top-4 left-4 bg-gold text-jungle-dark z-10" data-testid={`badge-featured-${product.id}`}>
                    Featured
                  </Badge>
                  <CardContent className="p-0">
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-48 object-cover rounded-t-xl"
                      data-testid={`img-featured-product-${product.id}`}
                    />
                    <div className="p-6">
                      <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-2" data-testid={`text-featured-product-name-${product.id}`}>
                        {product.name}
                      </h3>
                      <p className="text-gray-600 mb-4 text-sm" data-testid={`text-featured-product-description-${product.id}`}>
                        {product.description}
                      </p>
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold text-jungle-dark" data-testid={`text-featured-product-price-${product.id}`}>
                          {product.price}
                        </span>
                        <Button className="btn-shine px-4 py-2 rounded-full font-medium text-sm" data-testid={`button-featured-add-to-cart-${product.id}`}>
                          <ShoppingCart className="w-4 h-4 mr-1" />
                          Add to Cart
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Products */}
      <section className="py-20 bg-gray-50" data-testid="all-products">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12">
            <div>
              <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-all-products-title">
                All Products
              </h2>
              <p className="text-xl text-gray-600" data-testid="text-all-products-subtitle">
                Browse our complete range of cleaning products
              </p>
            </div>
            
            <div className="flex items-center space-x-4 mt-6 md:mt-0">
              <Filter className="text-gray-600" size={20} />
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48" data-testid="select-category-filter">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category} data-testid={`option-category-${category}`}>
                      {category === "all" ? "All Categories" : category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="card-hover" data-testid={`card-product-${product.id}`}>
                <CardContent className="p-0">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-48 object-cover rounded-t-xl"
                    data-testid={`img-product-${product.id}`}
                  />
                  <div className="p-6">
                    {product.category && (
                      <Badge variant="outline" className="mb-2" data-testid={`badge-product-category-${product.id}`}>
                        {product.category}
                      </Badge>
                    )}
                    <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-2" data-testid={`text-product-name-${product.id}`}>
                      {product.name}
                    </h3>
                    <p className="text-gray-600 mb-4 text-sm" data-testid={`text-product-description-${product.id}`}>
                      {product.description}
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-2xl font-bold text-jungle-dark" data-testid={`text-product-price-${product.id}`}>
                        {product.price}
                      </span>
                      <Button className="btn-shine px-4 py-2 rounded-full font-medium text-sm" data-testid={`button-add-to-cart-${product.id}`}>
                        <ShoppingCart className="w-4 h-4 mr-1" />
                        Add
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12" data-testid="no-products-message">
              <p className="text-gray-600 text-lg">No products found in this category.</p>
            </div>
          )}
        </div>
      </section>

      {/* Product Categories Info */}
      <section className="py-20 bg-white" data-testid="product-categories">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-categories-title">
              Product Categories
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-categories-subtitle">
              Comprehensive cleaning solutions for every need
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="card-hover text-center" data-testid="card-category-hand-care">
              <CardContent className="p-8">
                <div className="gold-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-jungle-dark text-2xl">🧴</span>
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Hand Care</h3>
                <p className="text-gray-600">Premium hand washes and sanitizers for personal hygiene and safety.</p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center" data-testid="card-category-cleaners">
              <CardContent className="p-8">
                <div className="gold-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-jungle-dark text-2xl">🧽</span>
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Surface Cleaners</h3>
                <p className="text-gray-600">Multi-purpose cleaners for all surfaces and specialized applications.</p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center" data-testid="card-category-sanitizers">
              <CardContent className="p-8">
                <div className="gold-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-jungle-dark text-2xl">🦠</span>
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Sanitizers</h3>
                <p className="text-gray-600">Hospital-grade disinfectants and sanitizers for maximum protection.</p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center" data-testid="card-category-equipment">
              <CardContent className="p-8">
                <div className="gold-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-jungle-dark text-2xl">🧹</span>
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Equipment</h3>
                <p className="text-gray-600">Professional cleaning tools and accessories for optimal results.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 jungle-gradient text-white" data-testid="products-cta">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-heading font-bold mb-6" data-testid="text-products-cta-title">
            Need Help Choosing Products?
          </h2>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto" data-testid="text-products-cta-subtitle">
            Our experts can help you select the right cleaning products for your specific needs and budget.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="btn-shine px-8 py-4 rounded-full font-semibold text-lg shadow-xl hover:shadow-2xl transition-all" data-testid="button-products-cta-consultation">
              Free Consultation
            </Button>
            <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white hover:text-jungle-dark transition-all" data-testid="button-products-cta-bulk-order">
              Bulk Orders
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
