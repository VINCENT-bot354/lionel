import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import UpdateBanner from "@/components/ui/update-banner";
import { Card, CardContent } from "@/components/ui/card";

interface TermsOfService {
  id: string;
  title: string;
  content: string;
  lastUpdated: string;
  isActive: boolean;
}

export default function TermsPage() {
  const { data: terms, isLoading } = useQuery<TermsOfService>({
    queryKey: ["/api/terms-of-service"],
  });

  return (
    <div className="min-h-screen bg-background">
      <UpdateBanner />
      <Navbar />
      
      <main className="py-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <Card>
            <CardContent className="p-8">
              {isLoading ? (
                <div className="space-y-4">
                  <div className="h-8 bg-gray-200 rounded animate-pulse"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded animate-pulse w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded animate-pulse w-1/2"></div>
                    <div className="h-4 bg-gray-200 rounded animate-pulse w-5/6"></div>
                  </div>
                </div>
              ) : terms ? (
                <div className="prose prose-lg max-w-none">
                  <h1 className="text-4xl font-heading font-bold text-jungle-dark mb-8" data-testid="text-terms-title">
                    {terms.title}
                  </h1>
                  
                  <div className="mb-8 text-sm text-gray-600">
                    Last updated: {new Date(terms.lastUpdated).toLocaleDateString()}
                  </div>

                  <div 
                    className="text-gray-700 leading-relaxed whitespace-pre-wrap"
                    data-testid="text-terms-content"
                    dangerouslySetInnerHTML={{ __html: terms.content.replace(/\n/g, '<br>') }}
                  />
                </div>
              ) : (
                <div className="text-center py-12">
                  <h1 className="text-4xl font-heading font-bold text-jungle-dark mb-4">
                    Terms of Service
                  </h1>
                  <p className="text-gray-600">
                    Terms of service content is not available at this time. Please contact us for more information.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}