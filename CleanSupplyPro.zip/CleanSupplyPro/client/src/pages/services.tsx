import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import UpdateBanner from "@/components/ui/update-banner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building, Home, Factory, CheckCircle, Clock, Users, Shield } from "lucide-react";

interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  image?: string;
  features?: any;
  price?: string;
  isActive: boolean;
  order: number;
}

const iconMap: Record<string, any> = {
  building: Building,
  home: Home,
  factory: Factory,
};

export default function ServicesPage() {
  const { data: services = [], isLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const activeServices = services.filter(service => service.isActive).sort((a, b) => a.order - b.order);

  // Default services if none in database
  const defaultServices = [
    {
      id: "commercial",
      title: "Commercial Cleaning",
      description: "Professional office and commercial space cleaning with eco-friendly products and flexible scheduling to meet your business needs.",
      icon: "building",
      features: ["Daily office cleaning", "Restroom sanitization", "Floor care & maintenance", "Window cleaning", "Carpet cleaning", "Emergency cleaning services"],
      price: "Starting at $150/month"
    },
    {
      id: "residential",
      title: "Residential Cleaning",
      description: "Thorough home cleaning services including deep cleaning, regular maintenance, and specialized treatments for a spotless living environment.",
      icon: "home",
      features: ["Weekly/bi-weekly cleaning", "Deep cleaning services", "Kitchen & bathroom deep clean", "Dusting & vacuuming", "Eco-friendly products", "Flexible scheduling"],
      price: "Starting at $120/session"
    },
    {
      id: "industrial",
      title: "Industrial Cleaning",
      description: "Heavy-duty cleaning for industrial facilities, warehouses, and specialized equipment maintenance with advanced cleaning technologies.",
      icon: "factory",
      features: ["Equipment cleaning", "Warehouse cleaning", "Safety compliance", "Heavy-duty degreasing", "Specialized waste removal", "24/7 availability"],
      price: "Custom pricing"
    }
  ];

  const displayServices = activeServices.length > 0 ? activeServices : defaultServices;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <UpdateBanner />
        <Navbar />
        <div className="container mx-auto px-4 py-20">
          <div className="grid md:grid-cols-3 gap-8">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="loading-shimmer h-96"></Card>
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UpdateBanner />
      <Navbar />
      
      {/* Hero Section */}
      <section className="jungle-gradient text-white py-20" data-testid="services-hero">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6" data-testid="text-services-hero-title">
              Professional Cleaning Services
            </h1>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto" data-testid="text-services-hero-subtitle">
              Comprehensive cleaning solutions tailored to your specific needs. From commercial offices to residential homes, we deliver exceptional results with eco-friendly products and professional expertise.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white" data-testid="services-grid">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-1 gap-12">
            {displayServices.map((service, index) => {
              const IconComponent = iconMap[service.icon] || Building;
              const isEven = index % 2 === 0;
              
              return (
                <Card key={service.id} className="card-hover overflow-hidden" data-testid={`card-service-${service.id}`}>
                  <div className={`grid md:grid-cols-2 gap-8 ${!isEven ? 'md:grid-flow-col-dense' : ''}`}>
                    <div className="p-8 flex flex-col justify-center">
                      <div className="flex items-center mb-6">
                        <div className="jungle-gradient w-16 h-16 rounded-full flex items-center justify-center mr-4">
                          <IconComponent className="text-white" size={24} />
                        </div>
                        <div>
                          <h2 className="text-3xl font-heading font-bold text-jungle-dark" data-testid={`text-service-title-${service.id}`}>
                            {service.title}
                          </h2>
                          {service.price && (
                            <Badge className="bg-gold text-jungle-dark mt-2" data-testid={`text-service-price-${service.id}`}>
                              {service.price}
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <p className="text-gray-600 mb-6 text-lg" data-testid={`text-service-description-${service.id}`}>
                        {service.description}
                      </p>

                      {(service.features || (service as any).features) && (
                        <div className="mb-6">
                          <h3 className="font-semibold text-jungle-dark mb-4">Service Features:</h3>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {((service.features || (service as any).features) as string[]).map((feature: string, idx: number) => (
                              <div key={idx} className="flex items-center space-x-2" data-testid={`feature-${service.id}-${idx}`}>
                                <CheckCircle className="text-jungle w-4 h-4 flex-shrink-0" />
                                <span className="text-gray-600 text-sm">{feature}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="flex gap-4">
                        <Button className="btn-shine px-6 py-3 rounded-full font-medium" data-testid={`button-service-quote-${service.id}`}>
                          Get Quote
                        </Button>
                        <Button variant="outline" className="border-jungle-dark text-jungle-dark hover:bg-jungle-light hover:text-white" data-testid={`button-service-learn-more-${service.id}`}>
                          Learn More
                        </Button>
                      </div>
                    </div>
                    
                    <div className={`${!isEven ? 'md:order-first' : ''}`}>
                      <img 
                        src={service.image || (index === 0 
                          ? "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                          : index === 1 
                          ? "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                          : "https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                        )}
                        alt={service.title}
                        className="w-full h-full object-cover min-h-[400px]"
                        data-testid={`img-service-${service.id}`}
                      />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50" data-testid="why-choose-us">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-why-choose-title">
              Why Choose M&M Cleaners?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-why-choose-subtitle">
              Experience the difference of professional cleaning services
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="card-hover text-center" data-testid="card-experienced">
              <CardContent className="p-8">
                <div className="gold-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Users className="text-jungle-dark" size={24} />
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">15+ Years Experience</h3>
                <p className="text-gray-600">Trusted expertise in commercial and residential cleaning services.</p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center" data-testid="card-licensed">
              <CardContent className="p-8">
                <div className="gold-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Shield className="text-jungle-dark" size={24} />
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Licensed & Insured</h3>
                <p className="text-gray-600">Full licensing and insurance coverage for your peace of mind.</p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center" data-testid="card-available">
              <CardContent className="p-8">
                <div className="gold-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Clock className="text-jungle-dark" size={24} />
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">24/7 Availability</h3>
                <p className="text-gray-600">Emergency cleaning services available when you need them most.</p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center" data-testid="card-eco-friendly">
              <CardContent className="p-8">
                <div className="gold-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="text-jungle-dark" size={24} />
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Eco-Friendly</h3>
                <p className="text-gray-600">Safe, environmentally responsible cleaning products and methods.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 jungle-gradient text-white" data-testid="cta-section">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-heading font-bold mb-6" data-testid="text-cta-title">
            Ready to Experience Professional Cleaning?
          </h2>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto" data-testid="text-cta-subtitle">
            Get a free quote today and discover why businesses and homeowners trust M&M Cleaners for their cleaning needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="btn-shine px-8 py-4 rounded-full font-semibold text-lg shadow-xl hover:shadow-2xl transition-all" data-testid="button-cta-quote">
              Get Free Quote
            </Button>
            <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white hover:text-jungle-dark transition-all" data-testid="button-cta-contact">
              Contact Us
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
