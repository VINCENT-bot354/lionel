import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import UpdateBanner from "@/components/ui/update-banner";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowRight } from "lucide-react";

interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt?: string;
  content?: string;
  image?: string;
  category?: string;
  type: string;
  isPublished: boolean;
  publishedAt: string;
}

export default function NewsPage() {
  const { data: articles = [], isLoading } = useQuery<Article[]>({
    queryKey: ["/api/articles"],
    queryFn: async () => {
      const response = await fetch("/api/articles?type=news");
      if (!response.ok) throw new Error("Failed to fetch news");
      return response.json();
    }
  });

  // Default news articles if none in database
  const defaultArticles = [
    {
      id: "residential-packages",
      title: "New Residential Cleaning Packages Now Available",
      slug: "new-residential-cleaning-packages",
      excerpt: "We're excited to announce our new flexible residential cleaning packages designed to meet every household's unique needs and budget requirements.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1484154218962-a197022b5858?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Services",
      type: "news",
      publishedAt: "2024-03-15T10:00:00Z",
      isPublished: true
    },
    {
      id: "eco-product-line",
      title: "Eco-Friendly Product Line Expansion",
      slug: "eco-friendly-product-line-expansion",
      excerpt: "Introducing our new range of certified eco-friendly cleaning products that deliver professional results while protecting the environment and your family's health.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Products",
      type: "news",
      publishedAt: "2024-03-10T14:30:00Z",
      isPublished: true
    },
    {
      id: "team-certification",
      title: "Team Training & Certification Update",
      slug: "team-training-certification-update",
      excerpt: "Our cleaning professionals have completed advanced certification training in the latest cleaning techniques, safety protocols, and customer service excellence.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Company",
      type: "news",
      publishedAt: "2024-03-05T09:15:00Z",
      isPublished: true
    },
    {
      id: "commercial-expansion",
      title: "Commercial Services Expansion to New Areas",
      slug: "commercial-services-expansion",
      excerpt: "M&M Cleaners is expanding our commercial cleaning services to serve businesses in three additional metropolitan areas, bringing our proven expertise to more clients.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Business",
      type: "news",
      publishedAt: "2024-02-28T16:45:00Z",
      isPublished: true
    },
    {
      id: "safety-protocols",
      title: "Enhanced Safety Protocols Implementation",
      slug: "enhanced-safety-protocols",
      excerpt: "We've implemented enhanced safety protocols and invested in new equipment to ensure the highest standards of health and safety for our clients and team members.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Safety",
      type: "news",
      publishedAt: "2024-02-20T11:20:00Z",
      isPublished: true
    },
    {
      id: "customer-appreciation",
      title: "Customer Appreciation Month Special Offers",
      slug: "customer-appreciation-month",
      excerpt: "This month we're celebrating our amazing customers with special offers, loyalty rewards, and exclusive discounts on our most popular services and products.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Promotions",
      type: "news",
      publishedAt: "2024-02-15T13:00:00Z",
      isPublished: true
    }
  ];

  const publishedArticles = articles.filter(article => article.isPublished && article.type === "news");
  const displayArticles = publishedArticles.length > 0 ? publishedArticles : defaultArticles;
  
  // Sort by published date, most recent first
  const sortedArticles = displayArticles.sort((a, b) => 
    new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );

  const featuredArticle = sortedArticles[0];
  const remainingArticles = sortedArticles.slice(1);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <UpdateBanner />
        <Navbar />
        <div className="container mx-auto px-4 py-20">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="loading-shimmer h-96"></Card>
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UpdateBanner />
      <Navbar />
      
      {/* Hero Section */}
      <section className="jungle-gradient text-white py-20" data-testid="news-hero">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6" data-testid="text-news-hero-title">
              Latest News & Updates
            </h1>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto" data-testid="text-news-hero-subtitle">
              Stay informed about our latest services, products, company updates, and industry insights from the M&M Cleaners team.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Article */}
      {featuredArticle && (
        <section className="py-20 bg-white" data-testid="featured-article">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <Badge className="bg-gold text-jungle-dark mb-4" data-testid="badge-featured">
                Featured News
              </Badge>
              <Card className="card-hover overflow-hidden" data-testid={`card-featured-${featuredArticle.id}`}>
                <div className="grid md:grid-cols-2 gap-0">
                  <div>
                    <img 
                      src={featuredArticle.image} 
                      alt={featuredArticle.title}
                      className="w-full h-full object-cover min-h-[300px]"
                      data-testid={`img-featured-${featuredArticle.id}`}
                    />
                  </div>
                  <div className="p-8 flex flex-col justify-center">
                    <div className="flex items-center text-sm text-gray-500 mb-4">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span data-testid={`text-featured-date-${featuredArticle.id}`}>
                        {new Date(featuredArticle.publishedAt).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </span>
                      {featuredArticle.category && (
                        <>
                          <span className="mx-2">•</span>
                          <Badge variant="outline" data-testid={`badge-featured-category-${featuredArticle.id}`}>
                            {featuredArticle.category}
                          </Badge>
                        </>
                      )}
                    </div>
                    <h2 className="text-3xl font-heading font-bold text-jungle-dark mb-4" data-testid={`text-featured-title-${featuredArticle.id}`}>
                      {featuredArticle.title}
                    </h2>
                    <p className="text-gray-600 mb-6" data-testid={`text-featured-excerpt-${featuredArticle.id}`}>
                      {featuredArticle.excerpt}
                    </p>
                    <Link href={`/news/${featuredArticle.slug}`}>
                      <Button className="btn-shine w-fit" data-testid={`button-featured-read-more-${featuredArticle.id}`}>
                        Read Full Article
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </section>
      )}

      {/* All News Articles */}
      <section className="py-20 bg-gray-50" data-testid="all-news">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-all-news-title">
              All News Articles
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-all-news-subtitle">
              Browse all our latest news and company updates
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {remainingArticles.map((article) => (
              <Card key={article.id} className="card-hover overflow-hidden" data-testid={`card-article-${article.id}`}>
                <CardContent className="p-0">
                  <img 
                    src={article.image} 
                    alt={article.title}
                    className="w-full h-48 object-cover"
                    data-testid={`img-article-${article.id}`}
                  />
                  <div className="p-6">
                    <div className="flex items-center text-sm text-gray-500 mb-3">
                      <Clock className="w-4 h-4 mr-2" />
                      <span data-testid={`text-article-date-${article.id}`}>
                        {new Date(article.publishedAt).toLocaleDateString()}
                      </span>
                      {article.category && (
                        <>
                          <span className="mx-2">•</span>
                          <Badge variant="outline" data-testid={`badge-article-category-${article.id}`}>
                            {article.category}
                          </Badge>
                        </>
                      )}
                    </div>
                    <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-3" data-testid={`text-article-title-${article.id}`}>
                      {article.title}
                    </h3>
                    <p className="text-gray-600 mb-4 text-sm line-clamp-3" data-testid={`text-article-excerpt-${article.id}`}>
                      {article.excerpt}
                    </p>
                    <Link href={`/news/${article.slug}`}>
                      <Button variant="outline" className="border-jungle text-jungle hover:bg-jungle-light hover:text-white w-full" data-testid={`button-article-read-more-${article.id}`}>
                        Read More
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {displayArticles.length === 0 && (
            <div className="text-center py-12" data-testid="no-news-message">
              <p className="text-gray-600 text-lg">No news articles available at this time.</p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-20 jungle-gradient text-white" data-testid="newsletter-signup">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-heading font-bold mb-6" data-testid="text-newsletter-title">
            Stay Updated
          </h2>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto" data-testid="text-newsletter-subtitle">
            Subscribe to our newsletter to receive the latest news, updates, and special offers directly in your inbox.
          </p>
          <div className="max-w-md mx-auto flex gap-4">
            <input 
              type="email" 
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-full text-jungle-dark"
              data-testid="input-newsletter-email"
            />
            <Button className="btn-shine px-6 py-3 rounded-full font-medium" data-testid="button-newsletter-subscribe">
              Subscribe
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
