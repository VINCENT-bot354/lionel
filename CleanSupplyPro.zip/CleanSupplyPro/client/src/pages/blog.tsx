import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import UpdateBanner from "@/components/ui/update-banner";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, User, ArrowRight, BookOpen } from "lucide-react";

interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt?: string;
  content?: string;
  image?: string;
  category?: string;
  type: string;
  isPublished: boolean;
  publishedAt: string;
}

export default function BlogPage() {
  const { data: articles = [], isLoading } = useQuery<Article[]>({
    queryKey: ["/api/articles"],
    queryFn: async () => {
      const response = await fetch("/api/articles?type=blog");
      if (!response.ok) throw new Error("Failed to fetch blog posts");
      return response.json();
    }
  });

  // Default blog articles if none in database
  const defaultArticles = [
    {
      id: "cleaning-tips-spring",
      title: "10 Essential Spring Cleaning Tips for a Fresh Home",
      slug: "spring-cleaning-tips-fresh-home",
      excerpt: "Spring is the perfect time for a deep clean. Discover our professional cleaning experts' top 10 tips to refresh your home and create a healthy living environment.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Cleaning Tips",
      type: "blog",
      publishedAt: "2024-03-18T10:00:00Z",
      isPublished: true
    },
    {
      id: "eco-friendly-benefits",
      title: "The Benefits of Eco-Friendly Cleaning Products",
      slug: "benefits-eco-friendly-cleaning-products",
      excerpt: "Learn why switching to eco-friendly cleaning products benefits your health, your family's safety, and the environment. Plus, discover which products to choose.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Eco-Friendly",
      type: "blog",
      publishedAt: "2024-03-12T14:30:00Z",
      isPublished: true
    },
    {
      id: "office-cleaning-productivity",
      title: "How Professional Office Cleaning Boosts Productivity",
      slug: "office-cleaning-boosts-productivity",
      excerpt: "Research shows that a clean workplace significantly impacts employee productivity and wellbeing. Learn how professional cleaning services can transform your office environment.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Business",
      type: "blog",
      publishedAt: "2024-03-08T09:15:00Z",
      isPublished: true
    },
    {
      id: "sanitization-guide",
      title: "Complete Guide to Proper Sanitization Techniques",
      slug: "complete-sanitization-guide",
      excerpt: "Master the art of proper sanitization with our comprehensive guide. Learn the difference between cleaning, disinfecting, and sanitizing for maximum protection.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Health & Safety",
      type: "blog",
      publishedAt: "2024-03-01T16:45:00Z",
      isPublished: true
    },
    {
      id: "stain-removal-guide",
      title: "Ultimate Stain Removal Guide: From Carpets to Upholstery",
      slug: "ultimate-stain-removal-guide",
      excerpt: "Don't let stains ruin your furniture or carpets. Our professional cleaners share their secrets for removing even the toughest stains safely and effectively.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Cleaning Tips",
      type: "blog",
      publishedAt: "2024-02-22T11:20:00Z",
      isPublished: true
    },
    {
      id: "seasonal-maintenance",
      title: "Seasonal Cleaning and Maintenance Checklist",
      slug: "seasonal-cleaning-maintenance-checklist",
      excerpt: "Stay on top of your cleaning routine with our seasonal checklist. Learn what tasks to prioritize each season to maintain a healthy and beautiful space year-round.",
      content: "Full article content here...",
      image: "https://images.unsplash.com/photo-1484154218962-a197022b5858?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      category: "Maintenance",
      type: "blog",
      publishedAt: "2024-02-15T13:00:00Z",
      isPublished: true
    }
  ];

  const publishedArticles = articles.filter(article => article.isPublished && article.type === "blog");
  const displayArticles = publishedArticles.length > 0 ? publishedArticles : defaultArticles;
  
  // Sort by published date, most recent first
  const sortedArticles = displayArticles.sort((a, b) => 
    new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );

  const featuredPost = sortedArticles[0];
  const recentPosts = sortedArticles.slice(1, 4);
  const remainingPosts = sortedArticles.slice(4);

  // Get unique categories
  const categories = Array.from(new Set(displayArticles.map(p => p.category).filter(Boolean)));

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <UpdateBanner />
        <Navbar />
        <div className="container mx-auto px-4 py-20">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="loading-shimmer h-96"></Card>
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <UpdateBanner />
      <Navbar />
      
      {/* Hero Section */}
      <section className="jungle-gradient text-white py-20" data-testid="blog-hero">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <div className="flex items-center justify-center mb-6">
              <BookOpen className="w-12 h-12 mr-4" />
              <h1 className="text-5xl md:text-6xl font-heading font-bold" data-testid="text-blog-hero-title">
                Cleaning Blog
              </h1>
            </div>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto" data-testid="text-blog-hero-subtitle">
              Expert tips, insights, and guides from professional cleaners. Learn the best practices for maintaining clean, healthy spaces at home and work.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Post */}
      {featuredPost && (
        <section className="py-20 bg-white" data-testid="featured-post">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <Badge className="bg-gold text-jungle-dark mb-6" data-testid="badge-featured">
                Featured Article
              </Badge>
              <Card className="card-hover overflow-hidden" data-testid={`card-featured-${featuredPost.id}`}>
                <div className="grid lg:grid-cols-2 gap-0">
                  <div>
                    <img 
                      src={featuredPost.image} 
                      alt={featuredPost.title}
                      className="w-full h-full object-cover min-h-[400px]"
                      data-testid={`img-featured-${featuredPost.id}`}
                    />
                  </div>
                  <div className="p-8 lg:p-12 flex flex-col justify-center">
                    <div className="flex items-center text-sm text-gray-500 mb-4">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span data-testid={`text-featured-date-${featuredPost.id}`}>
                        {new Date(featuredPost.publishedAt).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </span>
                      {featuredPost.category && (
                        <>
                          <span className="mx-2">•</span>
                          <Badge variant="outline" data-testid={`badge-featured-category-${featuredPost.id}`}>
                            {featuredPost.category}
                          </Badge>
                        </>
                      )}
                    </div>
                    <h2 className="text-3xl lg:text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid={`text-featured-title-${featuredPost.id}`}>
                      {featuredPost.title}
                    </h2>
                    <p className="text-gray-600 mb-6 text-lg" data-testid={`text-featured-excerpt-${featuredPost.id}`}>
                      {featuredPost.excerpt}
                    </p>
                    <Link href={`/blog/${featuredPost.slug}`}>
                      <Button className="btn-shine w-fit" data-testid={`button-featured-read-more-${featuredPost.id}`}>
                        Read Full Article
                        <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </section>
      )}

      {/* Recent Posts */}
      {recentPosts.length > 0 && (
        <section className="py-20 bg-gray-50" data-testid="recent-posts">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-recent-posts-title">
                Recent Articles
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-recent-posts-subtitle">
                Latest cleaning tips and insights from our experts
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {recentPosts.map((post) => (
                <Card key={post.id} className="card-hover overflow-hidden" data-testid={`card-recent-${post.id}`}>
                  <CardContent className="p-0">
                    <img 
                      src={post.image} 
                      alt={post.title}
                      className="w-full h-48 object-cover"
                      data-testid={`img-recent-${post.id}`}
                    />
                    <div className="p-6">
                      <div className="flex items-center text-sm text-gray-500 mb-3">
                        <Clock className="w-4 h-4 mr-2" />
                        <span data-testid={`text-recent-date-${post.id}`}>
                          {new Date(post.publishedAt).toLocaleDateString()}
                        </span>
                        {post.category && (
                          <>
                            <span className="mx-2">•</span>
                            <Badge variant="outline" data-testid={`badge-recent-category-${post.id}`}>
                              {post.category}
                            </Badge>
                          </>
                        )}
                      </div>
                      <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-3" data-testid={`text-recent-title-${post.id}`}>
                        {post.title}
                      </h3>
                      <p className="text-gray-600 mb-4 text-sm line-clamp-3" data-testid={`text-recent-excerpt-${post.id}`}>
                        {post.excerpt}
                      </p>
                      <Link href={`/blog/${post.slug}`}>
                        <Button variant="outline" className="border-jungle text-jungle hover:bg-jungle-light hover:text-white w-full" data-testid={`button-recent-read-more-${post.id}`}>
                          Read More
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Posts */}
      {remainingPosts.length > 0 && (
        <section className="py-20 bg-white" data-testid="all-posts">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-all-posts-title">
                More Articles
              </h2>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {remainingPosts.map((post) => (
                <Card key={post.id} className="card-hover overflow-hidden" data-testid={`card-post-${post.id}`}>
                  <CardContent className="p-0">
                    <img 
                      src={post.image} 
                      alt={post.title}
                      className="w-full h-48 object-cover"
                      data-testid={`img-post-${post.id}`}
                    />
                    <div className="p-6">
                      <div className="flex items-center text-sm text-gray-500 mb-3">
                        <Clock className="w-4 h-4 mr-2" />
                        <span data-testid={`text-post-date-${post.id}`}>
                          {new Date(post.publishedAt).toLocaleDateString()}
                        </span>
                        {post.category && (
                          <>
                            <span className="mx-2">•</span>
                            <Badge variant="outline" data-testid={`badge-post-category-${post.id}`}>
                              {post.category}
                            </Badge>
                          </>
                        )}
                      </div>
                      <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-3" data-testid={`text-post-title-${post.id}`}>
                        {post.title}
                      </h3>
                      <p className="text-gray-600 mb-4 text-sm line-clamp-3" data-testid={`text-post-excerpt-${post.id}`}>
                        {post.excerpt}
                      </p>
                      <Link href={`/blog/${post.slug}`}>
                        <Button variant="outline" className="border-jungle text-jungle hover:bg-jungle-light hover:text-white w-full" data-testid={`button-post-read-more-${post.id}`}>
                          Read More
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Categories */}
      {categories.length > 0 && (
        <section className="py-20 bg-gray-50" data-testid="blog-categories">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-categories-title">
                Browse by Category
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-categories-subtitle">
                Find articles that interest you most
              </p>
            </div>

            <div className="flex flex-wrap justify-center gap-4">
              {categories.map((category) => (
                <Badge 
                  key={category} 
                  variant="outline" 
                  className="px-6 py-3 text-lg border-jungle text-jungle hover:bg-jungle-light hover:text-white cursor-pointer transition-colors"
                  data-testid={`badge-category-${category?.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Newsletter Signup */}
      <section className="py-20 jungle-gradient text-white" data-testid="blog-newsletter">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-heading font-bold mb-6" data-testid="text-blog-newsletter-title">
            Never Miss a Cleaning Tip
          </h2>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto" data-testid="text-blog-newsletter-subtitle">
            Subscribe to our blog newsletter and get the latest cleaning tips, guides, and expert advice delivered to your inbox.
          </p>
          <div className="max-w-md mx-auto flex gap-4">
            <input 
              type="email" 
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-full text-jungle-dark"
              data-testid="input-blog-newsletter-email"
            />
            <Button className="btn-shine px-6 py-3 rounded-full font-medium" data-testid="button-blog-newsletter-subscribe">
              Subscribe
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
