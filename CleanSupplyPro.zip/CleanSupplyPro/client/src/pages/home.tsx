import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import UpdateBanner from "@/components/ui/update-banner";
import { Building, Home, Factory, Phone, ShoppingCart, Check, Star } from "lucide-react";

interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  image?: string;
  isActive: boolean;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: string;
  image?: string;
  isFeatured: boolean;
  isActive: boolean;
}

interface Testimonial {
  id: string;
  name: string;
  company?: string;
  content: string;
  rating: number;
  image?: string;
  isActive: boolean;
}

interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt?: string;
  image?: string;
  category?: string;
  publishedAt: string;
  type: string;
}

const iconMap: Record<string, any> = {
  building: Building,
  home: Home,
  factory: Factory,
};

export default function HomePage() {
  const { data: services = [] } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  const { data: featuredProducts = [] } = useQuery<Product[]>({
    queryKey: ["/api/products", { featured: "true" }],
  });

  const { data: testimonials = [] } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
  });

  const { data: newsArticles = [] } = useQuery<Article[]>({
    queryKey: ["/api/articles", { type: "news" }],
  });

  const heroServices = services.slice(0, 3);
  const displayProducts = featuredProducts.slice(0, 4);
  const displayTestimonials = testimonials.slice(0, 3);
  const latestNews = newsArticles.slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <UpdateBanner />
      <Navbar />
      
      {/* Hero Section */}
      <section className="jungle-gradient text-white py-20 relative overflow-hidden" data-testid="hero-section">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: "radial-gradient(circle at 25% 25%, rgba(255,255,255,0.1) 0%, transparent 50%)"
          }}></div>
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6 leading-tight" data-testid="text-hero-title">
                Professional Cleaning <span className="text-yellow-300">Solutions</span>
              </h1>
              <p className="text-xl mb-8 text-gray-200" data-testid="text-hero-subtitle">
                From commercial spaces to premium cleaning supplies, M&M Cleaners delivers exceptional results with our eco-friendly products and expert services.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/contact">
                  <Button className="btn-shine px-8 py-4 rounded-full font-semibold text-lg shadow-xl hover:shadow-2xl transition-all" data-testid="button-book-service">
                    <Phone className="mr-2" size={20} />
                    Book Service
                  </Button>
                </Link>
                <Link href="/products">
                  <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white hover:text-jungle-dark transition-all" data-testid="button-shop-products">
                    <ShoppingCart className="mr-2" size={20} />
                    Shop Products
                  </Button>
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-jungle-light to-jungle-dark rounded-2xl shadow-2xl p-12 text-center text-white">
                <div className="text-4xl font-bold mb-4">Professional</div>
                <div className="text-2xl mb-4">Cleaning Services</div>
                <div className="text-lg">Coming Soon</div>
              </div>
              <div className="absolute -bottom-6 -left-6 gold-gradient p-6 rounded-xl shadow-xl">
                <div className="text-jungle-dark text-center">
                  <div className="text-3xl font-bold">Professional</div>
                  <div className="text-sm font-medium">Quality Service</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white" id="services" data-testid="services-section">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-services-title">
              Our Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-services-subtitle">
              Comprehensive cleaning solutions tailored to your needs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {heroServices.map((service, index) => {
              const IconComponent = iconMap[service.icon] || Building;
              return (
                <Card key={service.id} className="card-hover cursor-pointer" data-testid={`card-service-${service.id}`}>
                  <CardContent className="p-8">
                    <div className="jungle-gradient w-16 h-16 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                      <IconComponent className="text-2xl text-white" size={24} />
                    </div>
                    <h3 className="text-2xl font-heading font-semibold text-jungle-dark mb-4" data-testid={`text-service-title-${service.id}`}>
                      {service.title}
                    </h3>
                    <p className="text-gray-600 mb-6" data-testid={`text-service-description-${service.id}`}>
                      {service.description}
                    </p>
                    <Button className="btn-shine px-6 py-3 rounded-full font-medium shadow-lg hover:shadow-xl transition-all" data-testid={`button-service-learn-more-${service.id}`}>
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              );
            })}

            {/* Show message if no services in database */}
            {heroServices.length === 0 && (
              <div className="col-span-3 text-center py-12">
                <h3 className="text-2xl font-heading font-semibold text-jungle-dark mb-4">Services Coming Soon</h3>
                <p className="text-gray-600">Our services are being added to the system. Please check back soon!</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-20 bg-gray-50" id="products" data-testid="products-section">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-products-title">
              Premium Cleaning Products
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-products-subtitle">
              Professional-grade cleaning supplies for all your needs
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {displayProducts.map((product) => (
              <Card key={product.id} className="card-hover" data-testid={`card-product-${product.id}`}>
                <CardContent className="p-6">
                  {product.image && (
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-48 object-cover rounded-xl mb-4 group-hover:scale-105 transition-transform"
                      data-testid={`img-product-${product.id}`}
                    />
                  )}
                  <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-2" data-testid={`text-product-name-${product.id}`}>
                    {product.name}
                  </h3>
                  <p className="text-gray-600 mb-4 text-sm" data-testid={`text-product-description-${product.id}`}>
                    {product.description}
                  </p>
                  <div className="flex justify-between items-center">
                    {product.price && (
                      <span className="text-2xl font-bold text-jungle-dark" data-testid={`text-product-price-${product.id}`}>
                        {product.price}
                      </span>
                    )}
                    <Button className="btn-shine px-4 py-2 rounded-full font-medium text-sm" data-testid={`button-add-to-cart-${product.id}`}>
                      Add to Cart
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Show message if no products in database */}
            {displayProducts.length === 0 && (
              <div className="col-span-4 text-center py-12">
                <h3 className="text-2xl font-heading font-semibold text-jungle-dark mb-4">Products Coming Soon</h3>
                <p className="text-gray-600">Our products are being added to the system. Please check back soon!</p>
              </div>
            )}
          </div>

          <div className="text-center mt-12">
            <Link href="/products">
              <Button className="btn-shine px-8 py-4 rounded-full font-semibold text-lg shadow-xl hover:shadow-2xl transition-all" data-testid="button-view-all-products">
                <ShoppingCart className="mr-2" size={20} />
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-white" id="about" data-testid="about-section">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="bg-gradient-to-br from-jungle-light to-jungle-dark rounded-2xl shadow-xl p-12 text-center text-white">
                <div className="text-3xl font-bold mb-4">Professional</div>
                <div className="text-xl mb-4">Cleaning Excellence</div>
                <div className="text-lg">Trusted by Thousands</div>
              </div>
            </div>
            <div>
              <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-6" data-testid="text-about-title">
                Why Choose M&M Cleaners?
              </h2>
              <p className="text-lg text-gray-600 mb-8" data-testid="text-about-description">
                M&M Cleaners has built a reputation for excellence, reliability, and customer satisfaction. We combine professional expertise with premium products to deliver outstanding results.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-4" data-testid="feature-eco-friendly">
                  <div className="jungle-gradient w-12 h-12 rounded-full flex items-center justify-center">
                    <Check className="text-white font-bold" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-jungle-dark">Eco-Friendly Products</h3>
                    <p className="text-gray-600 text-sm">Safe for your family and the environment</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4" data-testid="feature-professional">
                  <div className="jungle-gradient w-12 h-12 rounded-full flex items-center justify-center">
                    <Check className="text-white font-bold" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-jungle-dark">Professional Service</h3>
                    <p className="text-gray-600 text-sm">Quality cleaning with attention to detail</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4" data-testid="feature-availability">
                  <div className="jungle-gradient w-12 h-12 rounded-full flex items-center justify-center">
                    <Check className="text-white font-bold" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-jungle-dark">24/7 Availability</h3>
                    <p className="text-gray-600 text-sm">Emergency cleaning services when you need them</p>
                  </div>
                </div>
              </div>

              <Link href="/about">
                <Button className="btn-shine px-8 py-4 rounded-full font-semibold text-lg shadow-xl hover:shadow-2xl transition-all mt-8" data-testid="button-learn-more-about">
                  Learn More About Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 jungle-gradient text-white" data-testid="testimonials-section">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold mb-4" data-testid="text-testimonials-title">
              What Our Clients Say
            </h2>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto" data-testid="text-testimonials-subtitle">
              Trusted by businesses and homeowners across the region
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {displayTestimonials.map((testimonial) => (
              <Card key={testimonial.id} className="bg-white/10 backdrop-blur-sm border border-white/20" data-testid={`card-testimonial-${testimonial.id}`}>
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="gold-gradient w-12 h-12 rounded-full flex items-center justify-center mr-4">
                      <Star className="text-jungle-dark" size={20} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white" data-testid={`text-testimonial-name-${testimonial.id}`}>
                        {testimonial.name}
                      </h3>
                      {testimonial.company && (
                        <p className="text-gray-200 text-sm" data-testid={`text-testimonial-company-${testimonial.id}`}>
                          {testimonial.company}
                        </p>
                      )}
                    </div>
                  </div>
                  <p className="text-gray-200 mb-4" data-testid={`text-testimonial-content-${testimonial.id}`}>
                    {testimonial.content}
                  </p>
                  <div className="flex text-yellow-400">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="fill-current" size={16} />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Default testimonials if none in database */}
            {displayTestimonials.length === 0 && (
              <>
                <Card className="bg-white/10 backdrop-blur-sm border border-white/20">
                  <CardContent className="p-8">
                    <div className="flex items-center mb-6">
                      <div className="gold-gradient w-12 h-12 rounded-full flex items-center justify-center mr-4">
                        <Star className="text-jungle-dark" size={20} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">Sarah Johnson</h3>
                        <p className="text-gray-200 text-sm">ABC Corporation</p>
                      </div>
                    </div>
                    <p className="text-gray-200 mb-4">
                      "M&M Cleaners transformed our office space. Their attention to detail and professional approach is unmatched. Highly recommend!"
                    </p>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="fill-current" size={16} />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>
        </div>
      </section>

      {/* News Section */}
      <section className="py-20 bg-gray-50" id="news" data-testid="news-section">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-news-title">
              Latest News & Updates
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-news-subtitle">
              Stay informed about our latest services, products, and industry insights
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {latestNews.map((article) => (
              <Card key={article.id} className="card-hover overflow-hidden" data-testid={`card-article-${article.id}`}>
                {article.image && (
                  <img 
                    src={article.image} 
                    alt={article.title}
                    className="w-full h-48 object-cover"
                    data-testid={`img-article-${article.id}`}
                  />
                )}
                <CardContent className="p-6">
                  <div className="flex items-center text-sm text-gray-500 mb-3">
                    <span data-testid={`text-article-date-${article.id}`}>
                      {new Date(article.publishedAt).toLocaleDateString()}
                    </span>
                    {article.category && (
                      <>
                        <span className="mx-2">•</span>
                        <span data-testid={`text-article-category-${article.id}`}>{article.category}</span>
                      </>
                    )}
                  </div>
                  <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-3" data-testid={`text-article-title-${article.id}`}>
                    {article.title}
                  </h3>
                  {article.excerpt && (
                    <p className="text-gray-600 mb-4" data-testid={`text-article-excerpt-${article.id}`}>
                      {article.excerpt}
                    </p>
                  )}
                  <Button className="btn-shine px-6 py-2 rounded-full font-medium text-sm" data-testid={`button-read-more-${article.id}`}>
                    Read More
                  </Button>
                </CardContent>
              </Card>
            ))}

            {/* Default news if none in database */}
            {latestNews.length === 0 && (
              <Card className="card-hover overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1484154218962-a197022b5858?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                  alt="Modern home cleaning service" 
                  className="w-full h-48 object-cover"
                />
                <CardContent className="p-6">
                  <div className="flex items-center text-sm text-gray-500 mb-3">
                    <span>March 15, 2024</span>
                    <span className="mx-2">•</span>
                    <span>Services</span>
                  </div>
                  <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-3">New Residential Cleaning Packages</h3>
                  <p className="text-gray-600 mb-4">We're excited to announce our new flexible residential cleaning packages designed to meet every household's unique needs...</p>
                  <Button className="btn-shine px-6 py-2 rounded-full font-medium text-sm">Read More</Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
