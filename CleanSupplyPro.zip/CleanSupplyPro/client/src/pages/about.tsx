import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import UpdateBanner from "@/components/ui/update-banner";
import { Card, CardContent } from "@/components/ui/card";
import { Check, Users, Award, Clock, Shield } from "lucide-react";

interface Page {
  slug: string;
  title: string;
  content: any;
  metaDescription?: string;
  isPublished: boolean;
}

export default function AboutPage() {
  const { data: pageData } = useQuery<Page>({
    queryKey: ["/api/pages", "about"],
  });

  return (
    <div className="min-h-screen bg-background">
      <UpdateBanner />
      <Navbar />
      
      {/* Hero Section */}
      <section className="jungle-gradient text-white py-20" data-testid="about-hero">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6" data-testid="text-about-hero-title">
              {pageData?.title || "About M&M Cleaners"}
            </h1>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto" data-testid="text-about-hero-subtitle">
              {pageData?.metaDescription || "Your trusted cleaning partner, delivering exceptional results with professional expertise and eco-friendly products."}
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-white" data-testid="story-section">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-6" data-testid="text-story-title">
              Our Story
            </h2>
            <div className="space-y-4 text-gray-600">
              <p data-testid="text-story-paragraph-1">
                M&M Cleaners started as a small family business with a simple mission: to provide exceptional cleaning services that exceed our customers' expectations. What began as a local residential cleaning service has grown into a comprehensive cleaning solutions provider serving both residential and commercial clients across the region.
              </p>
              <p data-testid="text-story-paragraph-2">
                Our founders, Mike and Mary Johnson, recognized the need for reliable, eco-friendly cleaning services that prioritize both effectiveness and environmental responsibility. This vision has guided our company's growth and continues to drive our commitment to innovation and excellence.
              </p>
              <p data-testid="text-story-paragraph-3">
                Today, M&M Cleaners is proud to be a trusted partner for hundreds of satisfied customers, from busy families to large commercial enterprises. Our team of trained professionals uses state-of-the-art equipment and premium, environmentally safe products to deliver consistently outstanding results.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50" data-testid="values-section">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-values-title">
              Our Values
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-values-subtitle">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="card-hover text-center" data-testid="card-value-excellence">
              <CardContent className="p-8">
                <div className="jungle-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Excellence</h3>
                <p className="text-gray-600">We strive for perfection in every cleaning task, ensuring the highest quality results for our clients.</p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center" data-testid="card-value-reliability">
              <CardContent className="p-8">
                <div className="jungle-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Clock className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Reliability</h3>
                <p className="text-gray-600">Consistent, dependable service you can count on, delivered on time, every time.</p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center" data-testid="card-value-integrity">
              <CardContent className="p-8">
                <div className="jungle-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Shield className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Integrity</h3>
                <p className="text-gray-600">Honest, transparent business practices built on trust and mutual respect.</p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center" data-testid="card-value-innovation">
              <CardContent className="p-8">
                <div className="jungle-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Users className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-4">Innovation</h3>
                <p className="text-gray-600">Continuously improving our methods and adopting new technologies for better results.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      

      {/* Certifications & Awards */}
      <section className="py-20 bg-gray-50" data-testid="certifications-section">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-certifications-title">
              Certifications & Recognition
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-certifications-subtitle">
              Our commitment to excellence is recognized by industry leaders
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center" data-testid="certification-licensed">
              <div className="gold-gradient w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="text-jungle-dark" size={32} />
              </div>
              <h3 className="font-semibold text-jungle-dark mb-2">Professional Standards</h3>
              <p className="text-gray-600 text-sm">Meeting highest industry standards</p>
            </div>

            <div className="text-center" data-testid="certification-eco">
              <div className="gold-gradient w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="text-jungle-dark" size={32} />
              </div>
              <h3 className="font-semibold text-jungle-dark mb-2">Eco-Certified</h3>
              <p className="text-gray-600 text-sm">Green cleaning products and practices</p>
            </div>

            <div className="text-center" data-testid="certification-award">
              <div className="gold-gradient w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="text-jungle-dark" size={32} />
              </div>
              <h3 className="font-semibold text-jungle-dark mb-2">Industry Awards</h3>
              <p className="text-gray-600 text-sm">Recognized for service excellence</p>
            </div>

            <div className="text-center" data-testid="certification-trained">
              <div className="gold-gradient w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-jungle-dark" size={32} />
              </div>
              <h3 className="font-semibold text-jungle-dark mb-2">Trained Staff</h3>
              <p className="text-gray-600 text-sm">Certified and continuously trained professionals</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
