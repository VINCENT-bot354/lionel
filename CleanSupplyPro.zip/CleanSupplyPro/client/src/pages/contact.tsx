import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import UpdateBanner from "@/components/ui/update-banner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { MapPin, Phone, Mail, Clock, Send } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface ContactInfo {
  address: string;
  phone: string;
  email: string;
  hours: string;
  mapUrl?: string;
}

interface ContactFormData {
  firstName: string;
  lastName: string;
  email: string;
  service: string;
  message: string;
}

export default function ContactPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState<ContactFormData>({
    firstName: "",
    lastName: "",
    email: "",
    service: "",
    message: ""
  });

  const { data: contactInfo } = useQuery<ContactInfo>({
    queryKey: ["/api/contact-info"],
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message Sent Successfully!",
        description: "Thank you for contacting us. We'll get back to you within 24 hours.",
      });
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        service: "",
        message: ""
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error Sending Message",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (field: keyof ContactFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.message) {
      toast({
        title: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    contactMutation.mutate(formData);
  };

  // Default contact info if none in database
  const defaultContactInfo = {
    address: "123 Cleaning Street\nService City, SC 12345",
    phone: "(555) 123-4567",
    email: "info@mmcleaners.com",
    hours: "Mon-Fri: 8AM-6PM\nSat: 9AM-4PM\nSun: Emergency Only"
  };

  const displayContactInfo = contactInfo || defaultContactInfo;

  return (
    <div className="min-h-screen bg-background">
      <UpdateBanner />
      <Navbar />
      
      {/* Hero Section */}
      <section className="jungle-gradient text-white py-20" data-testid="contact-hero">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-heading font-bold mb-6" data-testid="text-contact-hero-title">
              Get In Touch
            </h1>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto" data-testid="text-contact-hero-subtitle">
              Ready to experience professional cleaning services? Contact us today for a free quote and discover why businesses and homeowners trust M&M Cleaners.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-white" data-testid="contact-section">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <h2 className="text-3xl font-heading font-bold text-jungle-dark mb-8" data-testid="text-contact-info-title">
                Contact Information
              </h2>
              
              <div className="space-y-8">
                <div className="flex items-start space-x-4" data-testid="contact-address">
                  <div className="jungle-gradient w-12 h-12 rounded-full flex items-center justify-center mt-1">
                    <MapPin className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-jungle-dark text-lg mb-2">Address</h3>
                    <p className="text-gray-600 whitespace-pre-line" data-testid="text-contact-address">
                      {displayContactInfo.address}
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4" data-testid="contact-phone">
                  <div className="jungle-gradient w-12 h-12 rounded-full flex items-center justify-center mt-1">
                    <Phone className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-jungle-dark text-lg mb-2">Phone</h3>
                    <p className="text-gray-600" data-testid="text-contact-phone">
                      {displayContactInfo.phone}
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4" data-testid="contact-email">
                  <div className="jungle-gradient w-12 h-12 rounded-full flex items-center justify-center mt-1">
                    <Mail className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-jungle-dark text-lg mb-2">Email</h3>
                    <p className="text-gray-600" data-testid="text-contact-email">
                      {displayContactInfo.email}
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4" data-testid="contact-hours">
                  <div className="jungle-gradient w-12 h-12 rounded-full flex items-center justify-center mt-1">
                    <Clock className="text-white" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-jungle-dark text-lg mb-2">Business Hours</h3>
                    <p className="text-gray-600 whitespace-pre-line" data-testid="text-contact-hours">
                      {displayContactInfo.hours}
                    </p>
                  </div>
                </div>
              </div>

              {/* Quick Contact Options */}
              <div className="mt-12">
                <h3 className="text-xl font-heading font-semibold text-jungle-dark mb-6" data-testid="text-quick-contact-title">
                  Quick Contact
                </h3>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button className="btn-shine flex-1" data-testid="button-call-now">
                    <Phone className="mr-2" size={16} />
                    Call Now
                  </Button>
                  <Button variant="outline" className="border-jungle text-jungle hover:bg-jungle-light hover:text-white flex-1" data-testid="button-email-us">
                    <Mail className="mr-2" size={16} />
                    Email Us
                  </Button>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <Card data-testid="contact-form-card">
                <CardContent className="p-8">
                  <h2 className="text-3xl font-heading font-bold text-jungle-dark mb-6" data-testid="text-contact-form-title">
                    Send Us a Message
                  </h2>
                  
                  <form onSubmit={handleSubmit} className="space-y-6" data-testid="contact-form">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName" className="text-jungle-dark font-medium">
                          First Name *
                        </Label>
                        <Input
                          id="firstName"
                          type="text"
                          value={formData.firstName}
                          onChange={(e) => handleInputChange("firstName", e.target.value)}
                          placeholder="John"
                          className="mt-2"
                          required
                          data-testid="input-first-name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName" className="text-jungle-dark font-medium">
                          Last Name *
                        </Label>
                        <Input
                          id="lastName"
                          type="text"
                          value={formData.lastName}
                          onChange={(e) => handleInputChange("lastName", e.target.value)}
                          placeholder="Doe"
                          className="mt-2"
                          required
                          data-testid="input-last-name"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email" className="text-jungle-dark font-medium">
                        Email Address *
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        placeholder="john@example.com"
                        className="mt-2"
                        required
                        data-testid="input-email"
                      />
                    </div>

                    <div>
                      <Label htmlFor="service" className="text-jungle-dark font-medium">
                        Service Needed
                      </Label>
                      <Select 
                        value={formData.service} 
                        onValueChange={(value) => handleInputChange("service", value)}
                      >
                        <SelectTrigger className="mt-2" data-testid="select-service">
                          <SelectValue placeholder="Select a service" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="commercial" data-testid="option-commercial">Commercial Cleaning</SelectItem>
                          <SelectItem value="residential" data-testid="option-residential">Residential Cleaning</SelectItem>
                          <SelectItem value="industrial" data-testid="option-industrial">Industrial Cleaning</SelectItem>
                          <SelectItem value="products" data-testid="option-products">Product Purchase</SelectItem>
                          <SelectItem value="other" data-testid="option-other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="message" className="text-jungle-dark font-medium">
                        Message *
                      </Label>
                      <Textarea
                        id="message"
                        value={formData.message}
                        onChange={(e) => handleInputChange("message", e.target.value)}
                        placeholder="Tell us about your cleaning needs..."
                        rows={4}
                        className="mt-2"
                        required
                        data-testid="textarea-message"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="btn-shine w-full py-4 text-lg font-semibold"
                      disabled={contactMutation.isPending}
                      data-testid="button-send-message"
                    >
                      <Send className="mr-2" size={20} />
                      {contactMutation.isPending ? "Sending..." : "Send Message"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-20 bg-gray-50" data-testid="service-areas">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold text-jungle-dark mb-4" data-testid="text-service-areas-title">
              Service Areas
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="text-service-areas-subtitle">
              We proudly serve the following areas with our professional cleaning services
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {["Downtown Area", "Business District", "Residential Zones", "Industrial Parks"].map((area, index) => (
              <Card key={index} className="text-center card-hover" data-testid={`card-service-area-${index}`}>
                <CardContent className="p-6">
                  <div className="gold-gradient w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="text-jungle-dark" size={24} />
                  </div>
                  <h3 className="font-semibold text-jungle-dark text-lg" data-testid={`text-service-area-${index}`}>
                    {area}
                  </h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="py-20 jungle-gradient text-white" data-testid="emergency-contact">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-heading font-bold mb-6" data-testid="text-emergency-title">
            Emergency Cleaning Services
          </h2>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto" data-testid="text-emergency-subtitle">
            Need immediate cleaning assistance? We offer 24/7 emergency cleaning services for urgent situations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="btn-shine px-8 py-4 rounded-full font-semibold text-lg shadow-xl hover:shadow-2xl transition-all" data-testid="button-emergency-call">
              <Phone className="mr-2" size={20} />
              Emergency Hotline
            </Button>
            <Button variant="outline" className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white hover:text-jungle-dark transition-all" data-testid="button-emergency-quote">
              24/7 Quote Request
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
