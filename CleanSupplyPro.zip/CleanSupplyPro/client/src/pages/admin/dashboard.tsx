import { Switch, Route } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";
import ContentEditor from "@/components/admin/content-editor";
import PasswordChange from "@/components/admin/password-change";
import ImageManager from "@/components/admin/image-manager";
import { 
  LayoutDashboard, Settings, FileText, Briefcase, Package, 
  Newspaper, Users, MessageSquare, Globe, LogOut, Home,
  Plus, Edit, Trash2, Eye, EyeOff, Lock, Image
} from "lucide-react";
import { Link, useLocation } from "wouter";

interface DashboardStats {
  services: number;
  products: number;
  articles: number;
  testimonials: number;
  contactSubmissions: number;
  activeBanners: number;
}

function Sidebar() {
  const [location] = useLocation();
  const { logout } = useAuth();

  const menuItems = [
    { label: "Dashboard", icon: LayoutDashboard, path: "/admin/dashboard" },
    { label: "Site Settings", icon: Settings, path: "/admin/site-config" },
    { label: "Pages", icon: FileText, path: "/admin/pages" },
    { label: "Services", icon: Briefcase, path: "/admin/services" },
    { label: "Products", icon: Package, path: "/admin/products" },
    { label: "News & Blog", icon: Newspaper, path: "/admin/articles" },
    { label: "Testimonials", icon: Users, path: "/admin/testimonials" },
    { label: "Contact Info", icon: Globe, path: "/admin/contact" },
    { label: "Messages", icon: MessageSquare, path: "/admin/messages" },
    { label: "Update Banners", icon: FileText, path: "/admin/banners" },
    { label: "Image Manager", icon: Image, path: "/admin/images" },
    { label: "Change Password", icon: Lock, path: "/admin/change-password" },
  ];

  return (
    <div className="w-64 jungle-gradient text-white min-h-screen p-6" data-testid="admin-sidebar">
      <div className="mb-8">
        <h1 className="text-xl font-heading font-bold" data-testid="text-admin-brand">
          M&M Cleaners CMS
        </h1>
      </div>

      <nav className="space-y-2">
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = location === item.path;
          
          return (
            <Link key={item.path} href={item.path}>
              <div 
                className={`flex items-center space-x-3 p-3 rounded-lg transition-colors cursor-pointer ${
                  isActive ? "bg-white/20" : "hover:bg-white/10"
                }`}
                data-testid={`sidebar-link-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <IconComponent size={18} />
                <span className="font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <Separator className="my-6 bg-white/20" />

      <div className="space-y-2">
        <Link href="/">
          <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 transition-colors cursor-pointer" data-testid="sidebar-link-view-site">
            <Home size={18} />
            <span className="font-medium">View Site</span>
          </div>
        </Link>
        
        <div 
          className="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          onClick={logout}
          data-testid="sidebar-link-logout"
        >
          <LogOut size={18} />
          <span className="font-medium">Logout</span>
        </div>
      </div>
    </div>
  );
}

function DashboardOverview() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/dashboard-stats"],
    queryFn: async () => {
      const token = localStorage.getItem('auth_token');
      const headers: HeadersInit = {};
      
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }

      // Fetch multiple endpoints for dashboard stats
      const [services, products, articles, testimonials, messages, banners] = await Promise.all([
        fetch("/api/admin/services", { headers }).then(r => r.json()),
        fetch("/api/admin/products", { headers }).then(r => r.json()),
        fetch("/api/admin/articles", { headers }).then(r => r.json()),
        fetch("/api/admin/testimonials", { headers }).then(r => r.json()),
        fetch("/api/admin/contact-submissions", { headers }).then(r => r.json()),
        fetch("/api/admin/banners", { headers }).then(r => r.json()),
      ]);

      return {
        services: services.length || 0,
        products: products.length || 0,
        articles: articles.length || 0,
        testimonials: testimonials.length || 0,
        contactSubmissions: messages.length || 0,
        activeBanners: banners.filter ? banners.filter((b: any) => b.isActive).length : 0,
      };
    },
  });

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="loading-shimmer h-32"></Card>
        ))}
      </div>
    );
  }

  const statCards = [
    { label: "Services", value: stats?.services || 0, color: "bg-blue-500" },
    { label: "Products", value: stats?.products || 0, color: "bg-green-500" },
    { label: "Articles", value: stats?.articles || 0, color: "bg-purple-500" },
    { label: "Testimonials", value: stats?.testimonials || 0, color: "bg-orange-500" },
    { label: "Messages", value: stats?.contactSubmissions || 0, color: "bg-red-500" },
    { label: "Active Banners", value: stats?.activeBanners || 0, color: "bg-yellow-500" },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-heading font-bold text-jungle-dark mb-2" data-testid="text-dashboard-title">
          Dashboard Overview
        </h1>
        <p className="text-gray-600" data-testid="text-dashboard-subtitle">
          Welcome to the M&M Cleaners content management system
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statCards.map((stat, index) => (
          <Card key={index} className="card-hover" data-testid={`card-stat-${stat.label.toLowerCase()}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600" data-testid={`text-stat-label-${index}`}>
                    {stat.label}
                  </p>
                  <p className="text-3xl font-bold text-jungle-dark" data-testid={`text-stat-value-${index}`}>
                    {stat.value}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-full ${stat.color} opacity-20`}></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <Card data-testid="quick-actions-card">
        <CardHeader>
          <CardTitle className="text-jungle-dark" data-testid="text-quick-actions-title">
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/admin/services">
              <Button className="btn-shine w-full" data-testid="button-add-service">
                <Plus className="mr-2" size={16} />
                Add Service
              </Button>
            </Link>
            <Link href="/admin/products">
              <Button className="btn-shine w-full" data-testid="button-add-product">
                <Plus className="mr-2" size={16} />
                Add Product
              </Button>
            </Link>
            <Link href="/admin/articles">
              <Button className="btn-shine w-full" data-testid="button-add-article">
                <Plus className="mr-2" size={16} />
                Add Article
              </Button>
            </Link>
            <Link href="/admin/banners">
              <Button className="btn-shine w-full" data-testid="button-add-banner">
                <Plus className="mr-2" size={16} />
                Add Banner
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function AdminRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loading-shimmer w-32 h-8 rounded"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <h2 className="text-xl font-semibold text-jungle-dark mb-4">Access Denied</h2>
            <p className="text-gray-600 mb-6">You must be logged in to access the admin panel.</p>
            <Link href="/admin/login">
              <Button className="btn-shine">Go to Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <Component />;
}

export default function AdminDashboard() {
  return (
    <div className="flex min-h-screen bg-gray-50 overflow-x-auto" data-testid="admin-dashboard">
      <Sidebar />
      <div className="flex-1 p-8 min-w-0">
        <Switch>
          <Route path="/admin/dashboard" component={() => <AdminRoute component={DashboardOverview} />} />
          <Route path="/admin/site-config" component={() => <AdminRoute component={() => <ContentEditor type="siteConfig" />} />} />
          <Route path="/admin/pages" component={() => <AdminRoute component={() => <ContentEditor type="pages" />} />} />
          <Route path="/admin/services" component={() => <AdminRoute component={() => <ContentEditor type="services" />} />} />
          <Route path="/admin/products" component={() => <AdminRoute component={() => <ContentEditor type="products" />} />} />
          <Route path="/admin/articles" component={() => <AdminRoute component={() => <ContentEditor type="articles" />} />} />
          <Route path="/admin/testimonials" component={() => <AdminRoute component={() => <ContentEditor type="testimonials" />} />} />
          <Route path="/admin/contact" component={() => <AdminRoute component={() => <ContentEditor type="contactInfo" />} />} />
          <Route path="/admin/messages" component={() => <AdminRoute component={() => <ContentEditor type="contactSubmissions" />} />} />
          <Route path="/admin/banners" component={() => <AdminRoute component={() => <ContentEditor type="banners" />} />} />
          <Route path="/admin/images" component={() => <AdminRoute component={ImageManager} />} />
          <Route path="/admin/change-password" component={() => <AdminRoute component={PasswordChange} />} />
          <Route component={() => <AdminRoute component={DashboardOverview} />} />
        </Switch>
      </div>
    </div>
  );
}
