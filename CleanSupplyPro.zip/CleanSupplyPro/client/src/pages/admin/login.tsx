import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { SprayCan, Lock, User } from "lucide-react";
import { useLocation } from "wouter";

export default function AdminLoginPage() {
  const [, setLocation] = useLocation();
  const { login, isLoading, error } = useAuth();
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await login(formData.username, formData.password);
    if (success) {
      setLocation("/admin/dashboard");
    }
  };

  const handleInputChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full space-y-8">
        {/* Logo and Title */}
        <div className="text-center">
          <div className="flex items-center justify-center mb-6">
            <div className="jungle-gradient p-4 rounded-full">
              <SprayCan className="text-white" size={32} />
            </div>
          </div>
          <h1 className="text-3xl font-heading font-bold text-jungle-dark" data-testid="text-admin-title">
            M&M Cleaners Admin
          </h1>
          <p className="text-gray-600 mt-2" data-testid="text-admin-subtitle">
            Content Management System
          </p>
        </div>

        {/* Login Form */}
        <Card data-testid="admin-login-card">
          <CardHeader>
            <CardTitle className="text-center text-jungle-dark" data-testid="text-login-title">
              Administrator Login
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6" data-testid="admin-login-form">
              {error && (
                <Alert variant="destructive" data-testid="alert-login-error">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div>
                <Label htmlFor="username" className="flex items-center text-jungle-dark font-medium">
                  <User className="w-4 h-4 mr-2" />
                  Username
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={formData.username}
                  onChange={(e) => handleInputChange("username", e.target.value)}
                  placeholder="Enter your username"
                  className="mt-2"
                  required
                  data-testid="input-admin-username"
                />
              </div>

              <div>
                <Label htmlFor="password" className="flex items-center text-jungle-dark font-medium">
                  <Lock className="w-4 h-4 mr-2" />
                  Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleInputChange("password", e.target.value)}
                  placeholder="Enter your password"
                  className="mt-2"
                  required
                  data-testid="input-admin-password"
                />
              </div>

              <Button 
                type="submit" 
                className="btn-shine w-full py-3 text-lg font-semibold"
                disabled={isLoading}
                data-testid="button-admin-login"
              >
                {isLoading ? "Signing In..." : "Sign In"}
              </Button>
            </form>

            {/* Demo Credentials */}
            <div className="mt-6 p-4 bg-gray-50 rounded-lg" data-testid="demo-credentials">
              <p className="text-sm text-gray-600 font-medium mb-2">Demo Credentials:</p>
              <p className="text-xs text-gray-500">Username: admin</p>
              <p className="text-xs text-gray-500">Password: admin123</p>
              <p className="text-xs text-gray-400 mt-2">
                Note: In production, create secure admin credentials via the registration endpoint.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center">
          <p className="text-sm text-gray-500" data-testid="text-login-footer">
            © 2024 M&M Cleaners & Supplies. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}
