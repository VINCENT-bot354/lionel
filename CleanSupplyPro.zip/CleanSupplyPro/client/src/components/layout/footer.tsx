import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { SprayCan, Facebook, Instagram, Linkedin, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";

interface SiteConfig {
  title: string;
  tagline: string;
}

interface ContactInfo {
  address: string;
  phone: string;
  email: string;
  hours: string;
}

interface SocialLink {
  id: string;
  platform: string;
  url: string;
  icon: string;
  isActive: boolean;
  order: number;
}

const socialIcons: Record<string, any> = {
  facebook: Facebook,
  instagram: Instagram,
  linkedin: Linkedin,
  twitter: Twitter,
};

export default function Footer() {
  const { data: siteConfig } = useQuery<SiteConfig>({
    queryKey: ["/api/site-config"],
  });

  const { data: contactInfo } = useQuery<ContactInfo>({
    queryKey: ["/api/contact-info"],
  });

  const { data: socialLinks = [] } = useQuery<SocialLink[]>({
    queryKey: ["/api/social-links"],
  });

  const currentYear = new Date().getFullYear();

  const serviceLinks = [
    { name: "Commercial Cleaning", href: "/services" },
    { name: "Residential Cleaning", href: "/services" },
    { name: "Industrial Cleaning", href: "/services" },
    { name: "Emergency Services", href: "/services" },
    { name: "Maintenance Plans", href: "/services" },
  ];

  const productLinks = [
    { name: "Hand Wash Products", href: "/products" },
    { name: "All-Purpose Cleaners", href: "/products" },
    { name: "Sanitizers", href: "/products" },
    { name: "Equipment", href: "/products" },
    { name: "Bulk Orders", href: "/products" },
  ];

  return (
    <footer className="jungle-gradient text-white py-16" data-testid="footer">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="gold-gradient p-3 rounded-full">
                <SprayCan className="text-2xl text-jungle-dark" size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-heading font-bold" data-testid="text-company-name">
                  {siteConfig?.title || "M&M CLEANERS"}
                </h3>
                <p className="text-sm text-gray-200">
                  {siteConfig?.tagline || "& SUPPLIES"}
                </p>
              </div>
            </div>
            <p className="text-gray-200 mb-6" data-testid="text-company-description">
              Professional cleaning services and premium products for all your needs. 
              Trusted by businesses and homeowners across the region.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((link) => {
                const IconComponent = socialIcons[link.platform.toLowerCase()];
                return (
                  <a
                    key={link.id}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="gold-gradient w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                    data-testid={`link-social-${link.platform.toLowerCase()}`}
                  >
                    {IconComponent ? (
                      <IconComponent className="text-jungle-dark" size={16} />
                    ) : (
                      <span className="text-jungle-dark text-sm font-bold">
                        {link.platform.charAt(0).toUpperCase()}
                      </span>
                    )}
                  </a>
                );
              })}
              {/* Default social links if none in database */}
              {socialLinks.length === 0 && (
                <>
                  <a
                    href="#"
                    className="gold-gradient w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                    data-testid="link-social-facebook"
                  >
                    <Facebook className="text-jungle-dark" size={16} />
                  </a>
                  <a
                    href="#"
                    className="gold-gradient w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                    data-testid="link-social-instagram"
                  >
                    <Instagram className="text-jungle-dark" size={16} />
                  </a>
                  <a
                    href="#"
                    className="gold-gradient w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                    data-testid="link-social-linkedin"
                  >
                    <Linkedin className="text-jungle-dark" size={16} />
                  </a>
                  <a
                    href="#"
                    className="gold-gradient w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
                    data-testid="link-social-twitter"
                  >
                    <Twitter className="text-jungle-dark" size={16} />
                  </a>
                </>
              )}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-xl font-heading font-semibold mb-6">Services</h4>
            <ul className="space-y-3 text-gray-200">
              {serviceLinks.map((service) => (
                <li key={service.name}>
                  <Link
                    href={service.href}
                    className="hover:text-yellow-300 transition-colors"
                    data-testid={`link-service-${service.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-xl font-heading font-semibold mb-6">Products</h4>
            <ul className="space-y-3 text-gray-200">
              {productLinks.map((product) => (
                <li key={product.name}>
                  <Link
                    href={product.href}
                    className="hover:text-yellow-300 transition-colors"
                    data-testid={`link-product-${product.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {product.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-xl font-heading font-semibold mb-6">Contact Info</h4>
            <div className="space-y-3 text-gray-200">
              <p data-testid="text-address">
                {contactInfo?.address || "123 Cleaning Street\nService City, SC 12345"}
              </p>
              <p data-testid="text-phone">
                {contactInfo?.phone || "(555) 123-4567"}
              </p>
              <p data-testid="text-email">
                {contactInfo?.email || "info@mmcleaners.com"}
              </p>
              <div className="mt-6">
                <Button className="btn-shine px-6 py-3 rounded-full font-medium" data-testid="button-footer-quote">
                  <span className="mr-2">📞</span>Get Quote
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="border-t border-white/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-200 text-sm" data-testid="text-copyright">
              © {currentYear} {siteConfig?.title || "M&M Cleaners and Supplies"}. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">

              <Link
                href="/terms"
                className="text-gray-200 hover:text-yellow-300 text-sm transition-colors"
                data-testid="link-terms"
              >
                Terms of Service
              </Link>
              <Link
                href="/admin/login"
                className="text-gray-200 hover:text-yellow-300 text-sm transition-colors"
                data-testid="link-admin"
              >
                Admin Login
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
