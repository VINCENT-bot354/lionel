import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, SprayCan } from "lucide-react";
import { cn } from "@/lib/utils";

interface SiteConfig {
  title: string;
  tagline: string;
}

interface MenuItem {
  id: string;
  label: string;
  url: string;
  order: number;
  isActive: boolean;
}

export default function Navbar() {
  const [location] = useLocation();
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const { data: siteConfig } = useQuery<SiteConfig>({
    queryKey: ["/api/site-config"],
  });

  const { data: menuItems = [] } = useQuery<MenuItem[]>({
    queryKey: ["/api/menu-items"],
  });

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  const defaultMenuItems = [
    { label: "Home", url: "/" },
    { label: "About", url: "/about" },
    { label: "Services", url: "/services" },
    { label: "Products", url: "/products" },
    { label: "News", url: "/news" },
    { label: "Blog", url: "/blog" },
    { label: "Contact", url: "/contact" },
    { label: "Terms", url: "/terms" },
  ];

  const displayMenuItems = menuItems.length > 0 ? menuItems : defaultMenuItems;

  return (
    <nav className="nav-shine sticky top-0 z-50 shadow-lg" data-testid="navbar">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex justify-between items-center py-3">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3" data-testid="link-home">
            <div className="jungle-gradient p-3 rounded-full">
              <SprayCan className="text-2xl text-white" size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-heading font-bold text-jungle-dark">
                {siteConfig?.title || "M&M CLEANERS"}
              </h1>
              <p className="text-sm text-jungle font-medium">
                {siteConfig?.tagline || "& SUPPLIES"}
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex space-x-6">
            {displayMenuItems.map((item) => (
              <Link
                key={item.url}
                href={item.url}
                className={cn(
                  "text-jungle-dark hover:text-jungle font-medium transition-colors px-2 py-1",
                  isActive(item.url) && "text-jungle font-semibold"
                )}
                data-testid={`link-${item.label.toLowerCase()}`}
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Mobile Menu */}
          <div className="flex items-center space-x-4">
            {/* Mobile Menu Trigger */}
            <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden text-jungle-dark ml-2" data-testid="button-mobile-menu">
                  <Menu size={24} />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80 gold-gradient [&>button]:!text-red-500 [&>button]:!w-8 [&>button]:!h-8">
                <div className="flex flex-col space-y-3 mt-8">
                  {displayMenuItems.map((item) => (
                    <Link
                      key={item.url}
                      href={item.url}
                      className={cn(
                        "text-lg font-medium transition-colors p-3 rounded-lg border border-transparent",
                        isActive(item.url) 
                          ? "text-jungle-dark bg-white/20 border-jungle-dark/20 font-semibold" 
                          : "text-jungle-dark hover:bg-white/10 hover:border-jungle-dark/10"
                      )}
                      onClick={() => setIsMobileOpen(false)}
                      data-testid={`mobile-link-${item.label.toLowerCase()}`}
                    >
                      {item.label}
                    </Link>
                  ))}
                  
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}