import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface UpdateBanner {
  id: string;
  text: string;
  backgroundColor: string;
  textColor: string;
  size: string;
  isActive: boolean;
  startDate: string;
  endDate?: string;
}

export default function UpdateBanner() {
  const [dismissedBanners, setDismissedBanners] = useState<string[]>(() => {
    const stored = localStorage.getItem('dismissedBanners');
    return stored ? JSON.parse(stored) : [];
  });

  const { data: banners = [] } = useQuery<UpdateBanner[]>({
    queryKey: ["/api/banners"],
  });

  const activeBanners = banners.filter(
    banner => banner.isActive && !dismissedBanners.includes(banner.id)
  );

  const dismissBanner = (bannerId: string) => {
    const newDismissed = [...dismissedBanners, bannerId];
    setDismissedBanners(newDismissed);
    localStorage.setItem('dismissedBanners', JSON.stringify(newDismissed));
  };

  if (activeBanners.length === 0) {
    return null;
  }

  return (
    <>
      {activeBanners.map((banner) => (
        <div
          key={banner.id}
          className={cn(
            "relative p-4 text-center",
            banner.size === "small" && "py-2",
            banner.size === "large" && "py-6"
          )}
          style={{
            backgroundColor: banner.backgroundColor,
            color: banner.textColor
          }}
          data-testid={`banner-${banner.id}`}
        >
          <div className="container mx-auto">
            <p className="font-medium" data-testid={`text-banner-${banner.id}`}>
              {banner.text}
            </p>
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-4 top-1/2 transform -translate-y-1/2 hover:bg-white/20"
              onClick={() => dismissBanner(banner.id)}
              data-testid={`button-dismiss-${banner.id}`}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ))}
    </>
  );
}