import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Plus, Edit, Trash2, Save, Eye, EyeOff, Upload, ExternalLink } from "lucide-react";

interface ContentEditorProps {
  type: "siteConfig" | "pages" | "services" | "products" | "articles" | "testimonials" | "contactInfo" | "contactSubmissions" | "banners" | "menuItems" | "socialLinks";
}

export default function ContentEditor({ type }: ContentEditorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [formData, setFormData] = useState<any>({});

  // Get correct endpoint for each type
  const getEndpoint = (contentType: string) => {
    switch (contentType) {
      case "siteConfig":
        return "/api/admin/site-config";
      case "contactInfo":
        return "/api/admin/contact-info";
      case "contactSubmissions":
        return "/api/admin/contact-submissions";
      case "socialLinks":
        return "/api/admin/social-links";
      case "menuItems":
        return "/api/admin/menu-items";
      default:
        return `/api/admin/${contentType}`;
    }
  };

  // Fetch data based on type
  const { data: items = [], isLoading } = useQuery({
    queryKey: [getEndpoint(type)],
  });

  // Mutations for CRUD operations
  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const endpoint = getEndpoint(type);
      const method = type === "siteConfig" || type === "contactInfo" ? "PUT" : "POST";
      const response = await apiRequest(method, endpoint, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [getEndpoint(type)] });
      setIsDialogOpen(false);
      setEditingItem(null);
      setFormData({});
      toast({ title: "Success", description: "Item saved successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const baseEndpoint = getEndpoint(type);
      const endpoint = type === "siteConfig" || type === "contactInfo" 
        ? baseEndpoint 
        : `${baseEndpoint}/${id}`;
      const response = await apiRequest("PUT", endpoint, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [getEndpoint(type)] });
      setIsDialogOpen(false);
      setEditingItem(null);
      setFormData({});
      toast({ title: "Success", description: "Item updated successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const baseEndpoint = getEndpoint(type);
      const endpoint = `${baseEndpoint}/${id}`;
      const response = await apiRequest("DELETE", endpoint);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [getEndpoint(type)] });
      toast({ title: "Success", description: "Item deleted successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const openEditDialog = (item?: any) => {
    setEditingItem(item || null);
    setFormData(item || getDefaultFormData());
    setIsDialogOpen(true);
  };

  const getDefaultFormData = () => {
    switch (type) {
      case "siteConfig":
        return { title: "", tagline: "", description: "" };
      case "pages":
        return { slug: "", title: "", content: "", metaDescription: "", isPublished: true };
      case "services":
        return { title: "", description: "", icon: "building", price: "", isActive: true, order: 0 };
      case "products":
        return { name: "", description: "", price: "", category: "", image: "", isActive: true, isFeatured: false, order: 0 };
      case "articles":
        return { title: "", slug: "", excerpt: "", content: "", type: "news", category: "", isPublished: true };
      case "testimonials":
        return { name: "", company: "", content: "", rating: 5, isActive: true, order: 0 };
      case "contactInfo":
        return { address: "", phone: "", email: "", hours: "", mapUrl: "" };
      case "banners":
        return { text: "", backgroundColor: "#2D5A27", textColor: "#FFFFFF", size: "medium", isActive: true };
      case "socialLinks":
        return { platform: "", url: "", icon: "", isActive: true, order: 0 };
      case "menuItems":
        return { label: "", url: "", order: 0, isActive: true };
      default:
        return {};
    }
  };

  const renderFormFields = () => {
    switch (type) {
      case "siteConfig":
        return (
          <>
            <div>
              <Label htmlFor="title">Site Title</Label>
              <Input
                id="title"
                value={formData.title || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                data-testid="input-site-title"
              />
            </div>
            <div>
              <Label htmlFor="tagline">Tagline</Label>
              <Input
                id="tagline"
                value={formData.tagline || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, tagline: e.target.value }))}
                data-testid="input-site-tagline"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                data-testid="textarea-site-description"
              />
            </div>
          </>
        );

      case "services":
        return (
          <>
            <div>
              <Label htmlFor="title">Service Title</Label>
              <Input
                id="title"
                value={formData.title || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                required
                data-testid="input-service-title"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                data-testid="textarea-service-description"
              />
            </div>
            <div>
              <Label htmlFor="icon">Icon</Label>
              <Select value={formData.icon} onValueChange={(value) => setFormData(prev => ({ ...prev, icon: value }))}>
                <SelectTrigger data-testid="select-service-icon">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="building">Building (Commercial)</SelectItem>
                  <SelectItem value="home">Home (Residential)</SelectItem>
                  <SelectItem value="factory">Factory (Industrial)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="price">Price (optional)</Label>
              <Input
                id="price"
                value={formData.price || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                placeholder="e.g., Starting at $150/month"
                data-testid="input-service-price"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
                data-testid="switch-service-active"
              />
              <Label>Active</Label>
            </div>
          </>
        );

      case "products":
        return (
          <>
            <div>
              <Label htmlFor="name">Product Name</Label>
              <Input
                id="name"
                value={formData.name || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                required
                data-testid="input-product-name"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                data-testid="textarea-product-description"
              />
            </div>
            <div>
              <Label htmlFor="price">Price</Label>
              <Input
                id="price"
                value={formData.price || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                placeholder="e.g., $12.99"
                data-testid="input-product-price"
              />
            </div>
            <div>
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                value={formData.category || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                data-testid="input-product-category"
              />
            </div>
            <div>
              <Label htmlFor="image">Image URL</Label>
              <Input
                id="image"
                value={formData.image || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, image: e.target.value }))}
                placeholder="https://example.com/image.jpg or upload file"
                data-testid="input-product-image"
              />
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
                  data-testid="switch-product-active"
                />
                <Label>Active</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.isFeatured}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isFeatured: checked }))}
                  data-testid="switch-product-featured"
                />
                <Label>Featured</Label>
              </div>
            </div>
          </>
        );

      case "pages":
        return (
          <>
            <div>
              <Label htmlFor="slug">Page Slug</Label>
              <Input
                id="slug"
                value={formData.slug || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                placeholder="about-us"
                required
                data-testid="input-page-slug"
              />
            </div>
            <div>
              <Label htmlFor="title">Page Title</Label>
              <Input
                id="title"
                value={formData.title || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                required
                data-testid="input-page-title"
              />
            </div>
            <div>
              <Label htmlFor="content">Content (HTML)</Label>
              <Textarea
                id="content"
                value={typeof formData.content === 'string' ? formData.content : JSON.stringify(formData.content || {})}
                onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                rows={8}
                data-testid="textarea-page-content"
              />
            </div>
            <div>
              <Label htmlFor="metaDescription">Meta Description</Label>
              <Textarea
                id="metaDescription"
                value={formData.metaDescription || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, metaDescription: e.target.value }))}
                data-testid="textarea-page-meta"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.isPublished}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isPublished: checked }))}
                data-testid="switch-page-published"
              />
              <Label>Published</Label>
            </div>
          </>
        );

      case "articles":
        return (
          <>
            <div>
              <Label htmlFor="title">Article Title</Label>
              <Input
                id="title"
                value={formData.title || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                required
                data-testid="input-article-title"
              />
            </div>
            <div>
              <Label htmlFor="slug">Article Slug</Label>
              <Input
                id="slug"
                value={formData.slug || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                placeholder="my-article-title"
                required
                data-testid="input-article-slug"
              />
            </div>
            <div>
              <Label htmlFor="excerpt">Excerpt</Label>
              <Textarea
                id="excerpt"
                value={formData.excerpt || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, excerpt: e.target.value }))}
                data-testid="textarea-article-excerpt"
              />
            </div>
            <div>
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                value={formData.content || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                rows={8}
                required
                data-testid="textarea-article-content"
              />
            </div>
            <div>
              <Label htmlFor="type">Type</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                <SelectTrigger data-testid="select-article-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="news">News</SelectItem>
                  <SelectItem value="blog">Blog</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                value={formData.category || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                data-testid="input-article-category"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.isPublished}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isPublished: checked }))}
                data-testid="switch-article-published"
              />
              <Label>Published</Label>
            </div>
          </>
        );

      case "testimonials":
        return (
          <>
            <div>
              <Label htmlFor="name">Customer Name</Label>
              <Input
                id="name"
                value={formData.name || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                required
                data-testid="input-testimonial-name"
              />
            </div>
            <div>
              <Label htmlFor="company">Company (optional)</Label>
              <Input
                id="company"
                value={formData.company || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, company: e.target.value }))}
                data-testid="input-testimonial-company"
              />
            </div>
            <div>
              <Label htmlFor="content">Testimonial</Label>
              <Textarea
                id="content"
                value={formData.content || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                required
                data-testid="textarea-testimonial-content"
              />
            </div>
            <div>
              <Label htmlFor="rating">Rating</Label>
              <Select value={String(formData.rating)} onValueChange={(value) => setFormData(prev => ({ ...prev, rating: parseInt(value) }))}>
                <SelectTrigger data-testid="select-testimonial-rating">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 Stars</SelectItem>
                  <SelectItem value="4">4 Stars</SelectItem>
                  <SelectItem value="3">3 Stars</SelectItem>
                  <SelectItem value="2">2 Stars</SelectItem>
                  <SelectItem value="1">1 Star</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="order">Display Order</Label>
              <Input
                id="order"
                type="number"
                value={formData.order || 0}
                onChange={(e) => setFormData(prev => ({ ...prev, order: parseInt(e.target.value) || 0 }))}
                data-testid="input-testimonial-order"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
                data-testid="switch-testimonial-active"
              />
              <Label>Active</Label>
            </div>
          </>
        );

      case "contactInfo":
        return (
          <>
            <div>
              <Label htmlFor="address">Address</Label>
              <Textarea
                id="address"
                value={formData.address || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                placeholder="123 Cleaning Street&#10;Service City, SC 12345"
                data-testid="textarea-contact-address"
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                value={formData.phone || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="(555) 123-4567"
                data-testid="input-contact-phone"
              />
            </div>
            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={formData.email || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                placeholder="info@mmcleaners.com"
                data-testid="input-contact-email"
              />
            </div>
            <div>
              <Label htmlFor="hours">Business Hours</Label>
              <Textarea
                id="hours"
                value={formData.hours || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, hours: e.target.value }))}
                placeholder="Mon-Fri: 8AM-6PM&#10;Sat: 9AM-4PM&#10;Sun: Emergency Only"
                data-testid="textarea-contact-hours"
              />
            </div>
            <div>
              <Label htmlFor="mapUrl">Map URL (optional)</Label>
              <Input
                id="mapUrl"
                value={formData.mapUrl || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, mapUrl: e.target.value }))}
                placeholder="https://maps.google.com/..."
                data-testid="input-contact-map"
              />
            </div>
          </>
        );

      case "socialLinks":
        return (
          <>
            <div>
              <Label htmlFor="platform">Platform</Label>
              <Select value={formData.platform} onValueChange={(value) => setFormData(prev => ({ ...prev, platform: value }))}>
                <SelectTrigger data-testid="select-social-platform">
                  <SelectValue placeholder="Select platform" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="facebook">Facebook</SelectItem>
                  <SelectItem value="twitter">Twitter</SelectItem>
                  <SelectItem value="instagram">Instagram</SelectItem>
                  <SelectItem value="linkedin">LinkedIn</SelectItem>
                  <SelectItem value="youtube">YouTube</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="url">URL</Label>
              <Input
                id="url"
                value={formData.url || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
                placeholder="https://facebook.com/mmcleaners"
                required
                data-testid="input-social-url"
              />
            </div>
            <div>
              <Label htmlFor="icon">Icon Class</Label>
              <Input
                id="icon"
                value={formData.icon || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, icon: e.target.value }))}
                placeholder="fab fa-facebook"
                data-testid="input-social-icon"
              />
            </div>
            <div>
              <Label htmlFor="order">Display Order</Label>
              <Input
                id="order"
                type="number"
                value={formData.order || 0}
                onChange={(e) => setFormData(prev => ({ ...prev, order: parseInt(e.target.value) || 0 }))}
                data-testid="input-social-order"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
                data-testid="switch-social-active"
              />
              <Label>Active</Label>
            </div>
          </>
        );

      case "menuItems":
        return (
          <>
            <div>
              <Label htmlFor="label">Menu Label</Label>
              <Input
                id="label"
                value={formData.label || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
                required
                data-testid="input-menu-label"
              />
            </div>
            <div>
              <Label htmlFor="url">URL</Label>
              <Input
                id="url"
                value={formData.url || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
                placeholder="/about"
                required
                data-testid="input-menu-url"
              />
            </div>
            <div>
              <Label htmlFor="order">Display Order</Label>
              <Input
                id="order"
                type="number"
                value={formData.order || 0}
                onChange={(e) => setFormData(prev => ({ ...prev, order: parseInt(e.target.value) || 0 }))}
                data-testid="input-menu-order"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
                data-testid="switch-menu-active"
              />
              <Label>Active</Label>
            </div>
          </>
        );

      case "banners":
        return (
          <>
            <div>
              <Label htmlFor="text">Banner Text</Label>
              <Input
                id="text"
                value={formData.text || ""}
                onChange={(e) => setFormData(prev => ({ ...prev, text: e.target.value }))}
                required
                placeholder="🎉 New Premium Hand Wash Products Now Available!"
                data-testid="input-banner-text"
              />
            </div>
            <div>
              <Label htmlFor="backgroundColor">Background Color</Label>
              <Input
                id="backgroundColor"
                type="color"
                value={formData.backgroundColor || "#2D5A27"}
                onChange={(e) => setFormData(prev => ({ ...prev, backgroundColor: e.target.value }))}
                data-testid="input-banner-bg-color"
              />
            </div>
            <div>
              <Label htmlFor="textColor">Text Color</Label>
              <Input
                id="textColor"
                type="color"
                value={formData.textColor || "#FFFFFF"}
                onChange={(e) => setFormData(prev => ({ ...prev, textColor: e.target.value }))}
                data-testid="input-banner-text-color"
              />
            </div>
            <div>
              <Label htmlFor="size">Size</Label>
              <Select value={formData.size} onValueChange={(value) => setFormData(prev => ({ ...prev, size: value }))}>
                <SelectTrigger data-testid="select-banner-size">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="small">Small</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="large">Large</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
                data-testid="switch-banner-active"
              />
              <Label>Active</Label>
            </div>
          </>
        );

      case "contactSubmissions":
        return (
          <Alert>
            <AlertDescription>
              Contact submissions are read-only. You can view and mark them as read, but cannot edit their content.
            </AlertDescription>
          </Alert>
        );

      default:
        return (
          <Alert>
            <AlertDescription>
              Form fields for {type} are not yet implemented in this demo.
            </AlertDescription>
          </Alert>
        );
    }
  };

  const getTitle = () => {
    switch (type) {
      case "siteConfig": return "Site Configuration";
      case "pages": return "Pages";
      case "services": return "Services";
      case "products": return "Products";
      case "articles": return "Articles";
      case "testimonials": return "Testimonials";
      case "contactInfo": return "Contact Information";
      case "contactSubmissions": return "Contact Messages";
      case "banners": return "Update Banners";
      case "socialLinks": return "Social Links";
      case "menuItems": return "Menu Items";
      default: return "Content Editor";
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card className="loading-shimmer h-32"></Card>
        <Card className="loading-shimmer h-96"></Card>
      </div>
    );
  }

  // For single-item types (siteConfig, contactInfo)
  if (type === "siteConfig" || type === "contactInfo") {
    const item = Array.isArray(items) ? items[0] : items;

    return (
      <div className="space-y-6">
        <Card data-testid={`card-${type}`}>
          <CardHeader>
            <CardTitle className="text-jungle-dark" data-testid={`text-${type}-title`}>
              {getTitle()}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {renderFormFields()}
              <Button 
                type="submit" 
                className="btn-shine"
                disabled={createMutation.isPending}
                data-testid={`button-save-${type}`}
              >
                <Save className="mr-2" size={16} />
                {createMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  // For list-based types
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-heading font-bold text-jungle-dark" data-testid={`text-${type}-page-title`}>
          {getTitle()}
        </h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="btn-shine" onClick={() => openEditDialog()} data-testid={`button-add-${type}`}>
              <Plus className="mr-2" size={16} />
              Add New
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle data-testid={`dialog-title-${type}`}>
                {editingItem ? `Edit ${type.slice(0, -1)}` : `Add New ${type.slice(0, -1)}`}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              {renderFormFields()}
              <div className="flex gap-4">
                <Button 
                  type="submit" 
                  className="btn-shine"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid={`button-save-${type}-item`}
                >
                  <Save className="mr-2" size={16} />
                  {(createMutation.isPending || updateMutation.isPending) ? "Saving..." : "Save"}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                  data-testid={`button-cancel-${type}`}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6">
        {Array.isArray(items) && items.map((item: any) => (
          <Card key={item.id} className="card-hover" data-testid={`card-${type}-item-${item.id}`}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-jungle-dark mb-2" data-testid={`text-${type}-item-title-${item.id}`}>
                    {item.title || item.name || item.text || item.label || "Untitled"}
                  </h3>
                  <p className="text-gray-600 mb-4" data-testid={`text-${type}-item-description-${item.id}`}>
                    {item.description || item.excerpt || item.content || "No description"}
                  </p>
                  <div className="flex gap-2">
                    {item.isActive !== undefined && (
                      <Badge variant={item.isActive ? "default" : "secondary"} data-testid={`badge-${type}-status-${item.id}`}>
                        {item.isActive ? "Active" : "Inactive"}
                      </Badge>
                    )}
                    {item.isFeatured && (
                      <Badge className="bg-gold text-jungle-dark" data-testid={`badge-${type}-featured-${item.id}`}>
                        Featured
                      </Badge>
                    )}
                    {item.category && (
                      <Badge variant="outline" data-testid={`badge-${type}-category-${item.id}`}>
                        {item.category}
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditDialog(item)}
                    data-testid={`button-edit-${type}-${item.id}`}
                  >
                    <Edit size={16} />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteMutation.mutate(item.id)}
                    disabled={deleteMutation.isPending}
                    data-testid={`button-delete-${type}-${item.id}`}
                  >
                    <Trash2 size={16} />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {(!Array.isArray(items) || items.length === 0) && (
          <Card data-testid={`card-${type}-empty`}>
            <CardContent className="p-12 text-center">
              <p className="text-gray-600 text-lg" data-testid={`text-${type}-empty`}>
                No {type} found. Click "Add New" to create your first item.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}