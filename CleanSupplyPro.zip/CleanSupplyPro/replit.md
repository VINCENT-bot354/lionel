# replit.md

## Overview

This is a full-stack web application for M&M Cleaners, a professional cleaning service company. The application serves as both a public-facing website showcasing services, products, and company information, and an admin dashboard for content management. Built with modern web technologies, it provides a responsive design with a custom brand theme featuring jungle green and gold colors.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript running on Vite for development and build tooling
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent UI components
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Authentication**: Context-based auth system with JWT tokens stored in localStorage
- **Component System**: Radix UI primitives with custom styling via class-variance-authority

### Backend Architecture
- **Runtime**: Node.js with Express.js web framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: JWT-based authentication with bcrypt for password hashing
- **File Uploads**: Multer middleware for handling multipart form data
- **Session Management**: PostgreSQL sessions with connect-pg-simple

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon serverless
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Database Tables**: Comprehensive schema including admin users, site configuration, pages, services, products, articles, testimonials, contact info, social links, and menu items

### Authentication and Authorization
- **Admin Authentication**: JWT token-based system with middleware protection
- **Password Security**: bcrypt hashing with salt rounds
- **Session Persistence**: localStorage for client-side token storage
- **Route Protection**: Admin middleware validates tokens on protected endpoints

### API Design
- **Architecture**: RESTful API with Express routes
- **Endpoints**: Separate public and admin API routes
- **Content Management**: Full CRUD operations for all content types
- **Request Handling**: JSON payloads with multipart support for file uploads
- **Error Handling**: Centralized error middleware with structured responses

### Development Environment
- **Build System**: Vite for frontend bundling and hot module replacement
- **Development Server**: Express server with Vite middleware integration
- **Type Safety**: Shared TypeScript schemas between frontend and backend
- **Path Aliases**: Configured import paths for cleaner code organization

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **WebSocket Support**: Custom WebSocket constructor for serverless compatibility

### UI Component Libraries
- **Radix UI**: Comprehensive collection of unstyled, accessible UI primitives
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Utility for creating variant-based component APIs

### Development Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer for browser compatibility
- **Replit Integration**: Development environment plugins and error handling

### Authentication & Security
- **JSON Web Tokens**: Industry standard for secure token-based authentication
- **bcrypt**: Cryptographic library for secure password hashing

### Form Management
- **React Hook Form**: Performant forms with minimal re-renders
- **Hookform Resolvers**: Integration with validation libraries
- **Zod**: TypeScript-first schema validation integrated with Drizzle

### File Handling
- **Multer**: Node.js middleware for handling multipart/form-data
- **File Type Validation**: Support for images, videos, and PDFs with size limits